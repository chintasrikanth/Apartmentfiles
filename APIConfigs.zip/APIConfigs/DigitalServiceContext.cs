using System;
using DigitalServices.Util;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DigitalServices.Data.Model
{
    public partial class DigitalServicesContext : DbContext
    {
        public DigitalServicesContext()
        {
        }

        public DigitalServicesContext(DbContextOptions<DigitalServicesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Address> Address { get; set; }
        public virtual DbSet<Application> Application { get; set; }
        public virtual DbSet<ApplicationDraft> ApplicationDraft { get; set; }
        public virtual DbSet<ApplicationSubmitted> ApplicationSubmitted { get; set; }
        public virtual DbSet<CommercialFishingApplication> CommercialFishingApplication { get; set; }
        public virtual DbSet<CommercialFishingBoatDetail> CommercialFishingBoatDetail { get; set; }
        public virtual DbSet<CommercialFishingBoatOwnerDetail> CommercialFishingBoatOwnerDetail { get; set; }
        public virtual DbSet<CommercialFishingComment> CommercialFishingComment { get; set; }
        public virtual DbSet<CommercialFishingDocumentsDetail> CommercialFishingDocumentsDetail { get; set; }
        public virtual DbSet<CommercialFishingPaymentDetail> CommercialFishingPaymentDetail { get; set; }
        public virtual DbSet<CommercialFishingStatusChangeHistory> CommercialFishingStatusChangeHistory { get; set; }
        public virtual DbSet<CompanyStakeHolder> CompanyStakeHolder { get; set; }
        public virtual DbSet<ConditionDeleted> ConditionDeleted { get; set; }
        public virtual DbSet<CtActivitySpecificQuestionnaire> CtActivitySpecificQuestionnaire { get; set; }
        public virtual DbSet<CtEqspermitCondition> CtEqspermitCondition { get; set; }
        public virtual DbSet<CtEqsquestionnaire> CtEqsquestionnaire { get; set; }
        public virtual DbSet<CtFee> CtFee { get; set; }
        public virtual DbSet<CtGeneralQuestionnaire> CtGeneralQuestionnaire { get; set; }
        public virtual DbSet<CtPermitValidityDuration> CtPermitValidityDuration { get; set; }
        public virtual DbSet<CtProfileTypeRoleMenuMapping> CtProfileTypeRoleMenuMapping { get; set; }
        public virtual DbSet<CtSectorSpecificQuestionnaire> CtSectorSpecificQuestionnaire { get; set; }
        public virtual DbSet<CtTeamMember> CtTeamMember { get; set; }
        public virtual DbSet<CtUserRoleMapping> CtUserRoleMapping { get; set; }
        public virtual DbSet<CustomerDeleted> CustomerDeleted { get; set; }
        public virtual DbSet<CustomerIndividualDeleted> CustomerIndividualDeleted { get; set; }
        public virtual DbSet<DecisionStatusDeleted> DecisionStatusDeleted { get; set; }
        public virtual DbSet<EmailMasterDeleted> EmailMasterDeleted { get; set; }
        public virtual DbSet<EqsactivityMapping> EqsactivityMapping { get; set; }
        public virtual DbSet<EqsadministrativeDetails> EqsadministrativeDetails { get; set; }
        public virtual DbSet<Eqsapplication> Eqsapplication { get; set; }
        public virtual DbSet<EqsapplicationAssistanceComments> EqsapplicationAssistanceComments { get; set; }
        public virtual DbSet<EqsapplicationComments> EqsapplicationComments { get; set; }
        public virtual DbSet<EqsapplicationDocumentsUpload> EqsapplicationDocumentsUpload { get; set; }
        public virtual DbSet<EqsapplicationPermitCondition> EqsapplicationPermitCondition { get; set; }
        public virtual DbSet<EqsapplicationQuestionnaireAnswers> EqsapplicationQuestionnaireAnswers { get; set; }
        public virtual DbSet<EqsapplicationReport> EqsapplicationReport { get; set; }
        public virtual DbSet<EqsapplicationReportStatusHistory> EqsapplicationReportStatusHistory { get; set; }
        public virtual DbSet<EqsapplicationStatusHistory> EqsapplicationStatusHistory { get; set; }
        public virtual DbSet<EqsapplicationStudy> EqsapplicationStudy { get; set; }
        public virtual DbSet<EqsapplicationStudyDocumentUpload> EqsapplicationStudyDocumentUpload { get; set; }
        public virtual DbSet<EqsapplicationStudyReviewCriteria> EqsapplicationStudyReviewCriteria { get; set; }
        public virtual DbSet<EqsapplicationStudyStatusHistory> EqsapplicationStudyStatusHistory { get; set; }
        public virtual DbSet<EqsinternalForm> EqsinternalForm { get; set; }
        public virtual DbSet<EqsrequestForAssistance> EqsrequestForAssistance { get; set; }
        public virtual DbSet<EqstechnicalDetails> EqstechnicalDetails { get; set; }
        public virtual DbSet<ErrorDeleted> ErrorDeleted { get; set; }
        public virtual DbSet<Exceptionlog> Exceptionlog { get; set; }
        public virtual DbSet<GroundWaterApplication> GroundWaterApplication { get; set; }
        public virtual DbSet<GroundWaterComment> GroundWaterComment { get; set; }
        public virtual DbSet<GroundWaterCustomerContractorMapping> GroundWaterCustomerContractorMapping { get; set; }
        public virtual DbSet<GroundWaterExistingWell> GroundWaterExistingWell { get; set; }
        public virtual DbSet<GroundWaterPayment> GroundWaterPayment { get; set; }
        public virtual DbSet<GroundWaterStatusChangeHistory> GroundWaterStatusChangeHistory { get; set; }
        public virtual DbSet<IdphousingMallProjectDetails> IdphousingMallProjectDetails { get; set; }
        public virtual DbSet<IdpliveStockAgricultureProjectDetails> IdpliveStockAgricultureProjectDetails { get; set; }
        public virtual DbSet<IdpmarineDreadgingProjectDetails> IdpmarineDreadgingProjectDetails { get; set; }
        public virtual DbSet<IdpotherProjectDetails> IdpotherProjectDetails { get; set; }
        public virtual DbSet<IdppipelineElectricCableProjectDetails> IdppipelineElectricCableProjectDetails { get; set; }
        public virtual DbSet<IdpprojectClassificationMapping> IdpprojectClassificationMapping { get; set; }
        public virtual DbSet<IdpquestionnaireAnswer> IdpquestionnaireAnswer { get; set; }
        public virtual DbSet<IdptourismLeisureProjectDetails> IdptourismLeisureProjectDetails { get; set; }
        public virtual DbSet<IdptransportProjectDetails> IdptransportProjectDetails { get; set; }
        public virtual DbSet<IdpwasteTreatementRelatedProjectDetails> IdpwasteTreatementRelatedProjectDetails { get; set; }
        public virtual DbSet<Inbox> Inbox { get; set; }
        public virtual DbSet<MtAccessLevel> MtAccessLevel { get; set; }
        public virtual DbSet<MtAction> MtAction { get; set; }
        public virtual DbSet<MtActionLanguage> MtActionLanguage { get; set; }
        public virtual DbSet<MtActivity> MtActivity { get; set; }
        public virtual DbSet<MtActivityLanguage> MtActivityLanguage { get; set; }
        public virtual DbSet<MtApplicationNumberConfiguration> MtApplicationNumberConfiguration { get; set; }
        public virtual DbSet<MtBoatBodyType> MtBoatBodyType { get; set; }
        public virtual DbSet<MtBoatBodyTypeLanguage> MtBoatBodyTypeLanguage { get; set; }
        public virtual DbSet<MtBoatType> MtBoatType { get; set; }
        public virtual DbSet<MtBoatTypeLanguage> MtBoatTypeLanguage { get; set; }
        public virtual DbSet<MtCity> MtCity { get; set; }
        public virtual DbSet<MtCityLanguage> MtCityLanguage { get; set; }
        public virtual DbSet<MtCommunicationType> MtCommunicationType { get; set; }
        public virtual DbSet<MtCommunicationTypeLanguage> MtCommunicationTypeLanguage { get; set; }
        public virtual DbSet<MtCompanyDelete> MtCompanyDelete { get; set; }
        public virtual DbSet<MtCompanyType> MtCompanyType { get; set; }
        public virtual DbSet<MtCompanyTypeLanguage> MtCompanyTypeLanguage { get; set; }
        public virtual DbSet<MtCompareOperator> MtCompareOperator { get; set; }
        public virtual DbSet<MtCountry> MtCountry { get; set; }
        public virtual DbSet<MtCountryLanguage> MtCountryLanguage { get; set; }
        public virtual DbSet<MtDeliveryType> MtDeliveryType { get; set; }
        public virtual DbSet<MtDeliveryTypeLanguage> MtDeliveryTypeLanguage { get; set; }
        public virtual DbSet<MtDepartment> MtDepartment { get; set; }
        public virtual DbSet<MtDepartmentLanguage> MtDepartmentLanguage { get; set; }
        public virtual DbSet<MtDesignation> MtDesignation { get; set; }
        public virtual DbSet<MtDesignationLanguage> MtDesignationLanguage { get; set; }
        public virtual DbSet<MtDistrictSector> MtDistrictSector { get; set; }
        public virtual DbSet<MtDistrictSectorLanguage> MtDistrictSectorLanguage { get; set; }
        public virtual DbSet<MtDocumentType> MtDocumentType { get; set; }
        public virtual DbSet<MtDocumentTypeLanguage> MtDocumentTypeLanguage { get; set; }
        public virtual DbSet<MtEmirateState> MtEmirateState { get; set; }
        public virtual DbSet<MtEmirateStateLanguage> MtEmirateStateLanguage { get; set; }
        public virtual DbSet<MtEqsassistanceType> MtEqsassistanceType { get; set; }
        public virtual DbSet<MtEqsassistanceTypeLanguage> MtEqsassistanceTypeLanguage { get; set; }
        public virtual DbSet<MtEqsclass> MtEqsclass { get; set; }
        public virtual DbSet<MtEqsclassLanguage> MtEqsclassLanguage { get; set; }
        public virtual DbSet<MtEqsclassReviewCriteria> MtEqsclassReviewCriteria { get; set; }
        public virtual DbSet<MtEqsclassReviewCriteriaLanguage> MtEqsclassReviewCriteriaLanguage { get; set; }
        public virtual DbSet<MtEqsgrade> MtEqsgrade { get; set; }
        public virtual DbSet<MtEqsgradeLanguage> MtEqsgradeLanguage { get; set; }
        public virtual DbSet<MtEqsownerType> MtEqsownerType { get; set; }
        public virtual DbSet<MtEqsownerTypeLanguage> MtEqsownerTypeLanguage { get; set; }
        public virtual DbSet<MtEqsresponseForm> MtEqsresponseForm { get; set; }
        public virtual DbSet<MtEqsresponseFormLanguage> MtEqsresponseFormLanguage { get; set; }
        public virtual DbSet<MtGender> MtGender { get; set; }
        public virtual DbSet<MtGenderLanguage> MtGenderLanguage { get; set; }
        public virtual DbSet<MtGeographicalDivision> MtGeographicalDivision { get; set; }
        public virtual DbSet<MtGeographicalDivisionLanguage> MtGeographicalDivisionLanguage { get; set; }
        public virtual DbSet<MtGroundWaterOperationalStatus> MtGroundWaterOperationalStatus { get; set; }
        public virtual DbSet<MtGroundWaterOperationalStatusLanguage> MtGroundWaterOperationalStatusLanguage { get; set; }
        public virtual DbSet<MtGroundWaterWellLocation> MtGroundWaterWellLocation { get; set; }
        public virtual DbSet<MtGroundWaterWellLocationLanguage> MtGroundWaterWellLocationLanguage { get; set; }
        public virtual DbSet<MtGroundWaterWellProductionStatus> MtGroundWaterWellProductionStatus { get; set; }
        public virtual DbSet<MtGroundWaterWellProductionStatusLanguage> MtGroundWaterWellProductionStatusLanguage { get; set; }
        public virtual DbSet<MtGroundWaterWellPurpose> MtGroundWaterWellPurpose { get; set; }
        public virtual DbSet<MtGroundWaterWellPurposeLanguage> MtGroundWaterWellPurposeLanguage { get; set; }
        public virtual DbSet<MtLanguage> MtLanguage { get; set; }
        public virtual DbSet<MtMeasurementUnit> MtMeasurementUnit { get; set; }
        public virtual DbSet<MtMeasurementUnitCategory> MtMeasurementUnitCategory { get; set; }
        public virtual DbSet<MtMeasurementUnitCategoryLanguage> MtMeasurementUnitCategoryLanguage { get; set; }
        public virtual DbSet<MtMeasurementUnitLanguage> MtMeasurementUnitLanguage { get; set; }
        public virtual DbSet<MtMenu> MtMenu { get; set; }
        public virtual DbSet<MtMenuLanguage> MtMenuLanguage { get; set; }
        public virtual DbSet<MtModeOfPayment> MtModeOfPayment { get; set; }
        public virtual DbSet<MtModeOfPaymentLanguage> MtModeOfPaymentLanguage { get; set; }
        public virtual DbSet<MtNatureOfBusiness> MtNatureOfBusiness { get; set; }
        public virtual DbSet<MtNatureOfBusinessLanguage> MtNatureOfBusinessLanguage { get; set; }
        public virtual DbSet<MtOrganizationType> MtOrganizationType { get; set; }
        public virtual DbSet<MtOrganizationTypeLanguage> MtOrganizationTypeLanguage { get; set; }
        public virtual DbSet<MtPage> MtPage { get; set; }
        public virtual DbSet<MtPaymentFor> MtPaymentFor { get; set; }
        public virtual DbSet<MtPaymentStatus> MtPaymentStatus { get; set; }
        public virtual DbSet<MtPaymentStatusLanguage> MtPaymentStatusLanguage { get; set; }
        public virtual DbSet<MtPermitCondition> MtPermitCondition { get; set; }
        public virtual DbSet<MtPermitConditionLanguage> MtPermitConditionLanguage { get; set; }
        public virtual DbSet<MtPort> MtPort { get; set; }
        public virtual DbSet<MtPortLanguage> MtPortLanguage { get; set; }
        public virtual DbSet<MtProcess> MtProcess { get; set; }
        public virtual DbSet<MtProcessCategory> MtProcessCategory { get; set; }
        public virtual DbSet<MtProcessLanguage> MtProcessLanguage { get; set; }
        public virtual DbSet<MtProductionGoesTo> MtProductionGoesTo { get; set; }
        public virtual DbSet<MtProductionGoesToLanguage> MtProductionGoesToLanguage { get; set; }
        public virtual DbSet<MtProfession> MtProfession { get; set; }
        public virtual DbSet<MtProfessionLanguage> MtProfessionLanguage { get; set; }
        public virtual DbSet<MtProfileType> MtProfileType { get; set; }
        public virtual DbSet<MtProfileTypeLanguage> MtProfileTypeLanguage { get; set; }
        public virtual DbSet<MtProjectClassification> MtProjectClassification { get; set; }
        public virtual DbSet<MtProjectClassificationLanguage> MtProjectClassificationLanguage { get; set; }
        public virtual DbSet<MtPropertyType> MtPropertyType { get; set; }
        public virtual DbSet<MtPropertyTypeLanguage> MtPropertyTypeLanguage { get; set; }
        public virtual DbSet<MtQuestionAnswerInputType> MtQuestionAnswerInputType { get; set; }
        public virtual DbSet<MtQuestionAnswerInputTypeLanguage> MtQuestionAnswerInputTypeLanguage { get; set; }
        public virtual DbSet<MtQuestionnaire> MtQuestionnaire { get; set; }
        public virtual DbSet<MtQuestionnaireAnswerConfiguration> MtQuestionnaireAnswerConfiguration { get; set; }
        public virtual DbSet<MtQuestionnaireAnswerConfigurationLanguage> MtQuestionnaireAnswerConfigurationLanguage { get; set; }
        public virtual DbSet<MtQuestionnaireCategory> MtQuestionnaireCategory { get; set; }
        public virtual DbSet<MtQuestionnaireCategoryLanguage> MtQuestionnaireCategoryLanguage { get; set; }
        public virtual DbSet<MtQuestionnaireLanguage> MtQuestionnaireLanguage { get; set; }
        public virtual DbSet<MtReportType> MtReportType { get; set; }
        public virtual DbSet<MtReportTypeLanguage> MtReportTypeLanguage { get; set; }
        public virtual DbSet<MtRole> MtRole { get; set; }
        public virtual DbSet<MtRoleLanguage> MtRoleLanguage { get; set; }
        public virtual DbSet<MtSector> MtSector { get; set; }
        public virtual DbSet<MtSectorLanguage> MtSectorLanguage { get; set; }
        public virtual DbSet<MtStakeHolderType> MtStakeHolderType { get; set; }
        public virtual DbSet<MtStakeHolderTypeLanguage> MtStakeHolderTypeLanguage { get; set; }
        public virtual DbSet<MtStatus> MtStatus { get; set; }
        public virtual DbSet<MtStatusLanguage> MtStatusLanguage { get; set; }
        public virtual DbSet<MtStudyType> MtStudyType { get; set; }
        public virtual DbSet<MtStudyTypeLanguage> MtStudyTypeLanguage { get; set; }
        public virtual DbSet<MtSubProcess> MtSubProcess { get; set; }
        public virtual DbSet<MtSubProcessLanguage> MtSubProcessLanguage { get; set; }
        public virtual DbSet<MtTeam> MtTeam { get; set; }
        public virtual DbSet<MtTeamLanguage> MtTeamLanguage { get; set; }
        public virtual DbSet<MtTitle> MtTitle { get; set; }
        public virtual DbSet<MtTitleLanguage> MtTitleLanguage { get; set; }
        public virtual DbSet<MtTreeSpecies> MtTreeSpecies { get; set; }
        public virtual DbSet<MtTreeSpeciesLanguage> MtTreeSpeciesLanguage { get; set; }
        public virtual DbSet<MtZone> MtZone { get; set; }
        public virtual DbSet<MtZoneLanguage> MtZoneLanguage { get; set; }
        public virtual DbSet<PaymentDetail> PaymentDetail { get; set; }
        public virtual DbSet<PermitConditionGroupDeleted> PermitConditionGroupDeleted { get; set; }
        public virtual DbSet<Profile> Profile { get; set; }
        public virtual DbSet<ProfileAddress> ProfileAddress { get; set; }
        public virtual DbSet<ProfileCompany> ProfileCompany { get; set; }
        public virtual DbSet<ProfileContractDetail> ProfileContractDetail { get; set; }
        public virtual DbSet<ProfileDocumentDetail> ProfileDocumentDetail { get; set; }
        public virtual DbSet<ProfileGovernment> ProfileGovernment { get; set; }
        public virtual DbSet<ProfileIndividual> ProfileIndividual { get; set; }
        public virtual DbSet<RecreationalFishingApplication> RecreationalFishingApplication { get; set; }
        public virtual DbSet<RecreationalFishingDeliveryAddress> RecreationalFishingDeliveryAddress { get; set; }
        public virtual DbSet<RecreationalFishingPaymentDetail> RecreationalFishingPaymentDetail { get; set; }
        public virtual DbSet<RecreationalFishingStatusChangeHistory> RecreationalFishingStatusChangeHistory { get; set; }
        public virtual DbSet<ResearchApplication> ResearchApplication { get; set; }
        public virtual DbSet<ResearchApplicationStatusChangeHistory> ResearchApplicationStatusChangeHistory { get; set; }
        public virtual DbSet<ResearchBiologicalSpecimen> ResearchBiologicalSpecimen { get; set; }
        public virtual DbSet<ResearchCollaborator> ResearchCollaborator { get; set; }
        public virtual DbSet<ResearchComment> ResearchComment { get; set; }
        public virtual DbSet<ResearchCoworkerDetail> ResearchCoworkerDetail { get; set; }
        public virtual DbSet<ResearchDelayDetailsComment> ResearchDelayDetailsComment { get; set; }
        public virtual DbSet<ResearchProjectDetail> ResearchProjectDetail { get; set; }
        public virtual DbSet<ResearchResearcherDetail> ResearchResearcherDetail { get; set; }
        public virtual DbSet<ResearchSupervisorDetail> ResearchSupervisorDetail { get; set; }
        public virtual DbSet<ResearchSupportingDocument> ResearchSupportingDocument { get; set; }
        public virtual DbSet<Review> Review { get; set; }
        public virtual DbSet<Sla> Sla { get; set; }
        public virtual DbSet<Threshold> Threshold { get; set; }
        public virtual DbSet<TreeTranslocationApplication> TreeTranslocationApplication { get; set; }
        public virtual DbSet<TreeTranslocationComment> TreeTranslocationComment { get; set; }
        public virtual DbSet<TreeTranslocationStatusChangeHistory> TreeTranslocationStatusChangeHistory { get; set; }
        public virtual DbSet<UploadedDocument> UploadedDocument { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserType> UserType { get; set; }
        public virtual DbSet<Workflow> Workflow { get; set; }

        // Unable to generate entity type for table 'dbo.MtCompareOperatorLanguage'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.OLE DB Destination'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.CtQuestionnairAnswer'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tmpID_Recreationaldelivery'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tmpIDNumberStaging_Recreational'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tmpIDNumberAnnual_Recreational'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // var connectionString = AppSettingsHelper.JwtSymmetricSecurityKey;
                //optionsBuilder.UseSqlServer("Server=10.17.64.120;Database=DigitalServices;User Id=DigitalServicesUser;Password=Ead@@123!@ ");
                optionsBuilder.UseSqlServer(Constants.DatabaseConnectionString); 
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Address>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Area).HasMaxLength(100);

                entity.Property(e => e.CityId).HasColumnName("CityID");

                entity.Property(e => e.CountryId).HasColumnName("CountryID");

                entity.Property(e => e.FaxNumber).HasMaxLength(20);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.Property(e => e.OfficeVillaNumber).HasMaxLength(10);

                entity.Property(e => e.PhoneNumber).HasMaxLength(20);

                entity.Property(e => e.PostBox).HasMaxLength(25);

                entity.Property(e => e.StreetBuilding).HasMaxLength(250);

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Address)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK_AddressInUAE_MtCity");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.Address)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("FK_AddressInUAE_MtCountry");
            });

            modelBuilder.Entity<Application>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationNumber).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");
            });

            modelBuilder.Entity<ApplicationDraft>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");
            });

            modelBuilder.Entity<ApplicationSubmitted>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationDraftId).HasColumnName("ApplicationDraftID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<CommercialFishingApplication>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.CommercialFishingBoatDetailsId).HasColumnName("CommercialFishingBoatDetailsID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeliveryTypeId).HasColumnName("DeliveryTypeID");

                entity.Property(e => e.ExpiryDate).HasColumnType("datetime");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LicenseNumber).HasMaxLength(50);

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.HasOne(d => d.CommercialFishingBoatDetails)
                    .WithMany(p => p.CommercialFishingApplication)
                    .HasForeignKey(d => d.CommercialFishingBoatDetailsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingApplication_CommercialFishingBoatDetail");

                entity.HasOne(d => d.DeliveryType)
                    .WithMany(p => p.CommercialFishingApplication)
                    .HasForeignKey(d => d.DeliveryTypeId)
                    .HasConstraintName("FK_CommercialFishingApplication_MtDeliveryType");
            });

            modelBuilder.Entity<CommercialFishingBoatDetail>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.BoatBodyTypeId).HasColumnName("BoatBodyTypeID");

                entity.Property(e => e.BoatLength).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.BoatNameAr)
                    .HasColumnName("BoatNameAR")
                    .HasMaxLength(250);

                entity.Property(e => e.BoatNameEn)
                    .HasColumnName("BoatNameEN")
                    .HasMaxLength(250);

                entity.Property(e => e.BoatNumber).HasMaxLength(20);

                entity.Property(e => e.BoatTypeId).HasColumnName("BoatTypeID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FishProductionGoesToId).HasColumnName("FishProductionGoesToID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.PortId).HasColumnName("PortID");

                entity.Property(e => e.Remarks).HasMaxLength(500);

                entity.Property(e => e.RowRevision).IsRowVersion();

                entity.HasOne(d => d.BoatBodyType)
                    .WithMany(p => p.CommercialFishingBoatDetail)
                    .HasForeignKey(d => d.BoatBodyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatDetail_MtBoatBodyType");

                entity.HasOne(d => d.BoatType)
                    .WithMany(p => p.CommercialFishingBoatDetail)
                    .HasForeignKey(d => d.BoatTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatDetail_MtBoatType");

                entity.HasOne(d => d.FishProductionGoesTo)
                    .WithMany(p => p.CommercialFishingBoatDetail)
                    .HasForeignKey(d => d.FishProductionGoesToId)
                    .HasConstraintName("FK_CommercialFishingBoatDetail_MtProductionGoesTo");

                entity.HasOne(d => d.Port)
                    .WithMany(p => p.CommercialFishingBoatDetail)
                    .HasForeignKey(d => d.PortId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatDetail_MtPort");
            });

            modelBuilder.Entity<CommercialFishingBoatOwnerDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommercialFishingBoatDetailsId).HasColumnName("CommercialFishingBoatDetailsID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Email).HasMaxLength(255);

                entity.Property(e => e.EmirateStateId).HasColumnName("EmirateStateID");

                entity.Property(e => e.EmiratesId)
                    .HasColumnName("EmiratesID")
                    .HasMaxLength(50);

                entity.Property(e => e.GenderId).HasColumnName("GenderID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Mobile).HasMaxLength(15);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.OwnerFirstAr)
                    .HasColumnName("OwnerFirstAR")
                    .HasMaxLength(255);

                entity.Property(e => e.OwnerFistEn)
                    .HasColumnName("OwnerFistEN")
                    .HasMaxLength(255);

                entity.Property(e => e.OwnerLastAr)
                    .HasColumnName("OwnerLastAR")
                    .HasMaxLength(255);

                entity.Property(e => e.OwnerLastEn)
                    .HasColumnName("OwnerLastEN")
                    .HasMaxLength(255);

                entity.Property(e => e.OwnerMiddleAr)
                    .HasColumnName("OwnerMiddleAR")
                    .HasMaxLength(255);

                entity.Property(e => e.OwnerMiddleEn)
                    .HasColumnName("OwnerMiddleEN")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfessionId).HasColumnName("ProfessionID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.HasOne(d => d.CommercialFishingBoatDetails)
                    .WithMany(p => p.CommercialFishingBoatOwnerDetail)
                    .HasForeignKey(d => d.CommercialFishingBoatDetailsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatOwnerDetail_CommercialFishingBoatDetail");

                entity.HasOne(d => d.EmirateState)
                    .WithMany(p => p.CommercialFishingBoatOwnerDetail)
                    .HasForeignKey(d => d.EmirateStateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatOwnerDetail_MtEmirateState");

                entity.HasOne(d => d.Gender)
                    .WithMany(p => p.CommercialFishingBoatOwnerDetail)
                    .HasForeignKey(d => d.GenderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatOwnerDetail_MtGender");

                entity.HasOne(d => d.Profession)
                    .WithMany(p => p.CommercialFishingBoatOwnerDetail)
                    .HasForeignKey(d => d.ProfessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingBoatOwnerDetail_MtProfession");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.CommercialFishingBoatOwnerDetail)
                    .HasForeignKey(d => d.TitleId)
                    .HasConstraintName("FK_CommercialFishingBoatOwnerDetail_MtTitle");
            });

            modelBuilder.Entity<CommercialFishingComment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommercialFishingApplicationId).HasColumnName("CommercialFishingApplicationID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UploadedDocumentId).HasColumnName("UploadedDocumentID");

                entity.HasOne(d => d.CommercialFishingApplication)
                    .WithMany(p => p.CommercialFishingComment)
                    .HasForeignKey(d => d.CommercialFishingApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingComment_CommercialFishingApplication");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.CommercialFishingComment)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_CommercialFishingComment_MtRole");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.CommercialFishingComment)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .HasConstraintName("FK_CommercialFishingComment_UploadedDocument");
            });

            modelBuilder.Entity<CommercialFishingDocumentsDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommercialFishingBoatDetailsId).HasColumnName("CommercialFishingBoatDetailsID");

                entity.Property(e => e.OtherSupportingFilesId).HasColumnName("OtherSupportingFilesID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.UploadedBoatRegistrationId).HasColumnName("UploadedBoatRegistrationID");

                entity.Property(e => e.UploadedCriminalStatusCertificateId).HasColumnName("UploadedCriminalStatusCertificateID");

                entity.Property(e => e.UploadedEmiratesId).HasColumnName("UploadedEmiratesID");

                entity.Property(e => e.UploadedPhotographId).HasColumnName("UploadedPhotographID");

                entity.HasOne(d => d.CommercialFishingBoatDetails)
                    .WithMany(p => p.CommercialFishingDocumentsDetail)
                    .HasForeignKey(d => d.CommercialFishingBoatDetailsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingDocumentsDetail_CommercialFishingBoatDetail");

                entity.HasOne(d => d.OtherSupportingFiles)
                    .WithMany(p => p.CommercialFishingDocumentsDetailOtherSupportingFiles)
                    .HasForeignKey(d => d.OtherSupportingFilesId)
                    .HasConstraintName("FK_CommercialFishingDocumentsDetail_UploadedDocument_SupportingFileID");

                entity.HasOne(d => d.UploadedBoatRegistration)
                    .WithMany(p => p.CommercialFishingDocumentsDetailUploadedBoatRegistration)
                    .HasForeignKey(d => d.UploadedBoatRegistrationId)
                    .HasConstraintName("FK_CommercialFishingDocumentsDetail_UploadedDocument_RegistrationID");

                entity.HasOne(d => d.UploadedCriminalStatusCertificate)
                    .WithMany(p => p.CommercialFishingDocumentsDetailUploadedCriminalStatusCertificate)
                    .HasForeignKey(d => d.UploadedCriminalStatusCertificateId)
                    .HasConstraintName("FK_CommercialFishingDocumentsDetail_UploadedDocument_CriminalStatusCertificate");

                entity.HasOne(d => d.UploadedEmirates)
                    .WithMany(p => p.CommercialFishingDocumentsDetailUploadedEmirates)
                    .HasForeignKey(d => d.UploadedEmiratesId);

                entity.HasOne(d => d.UploadedPhotograph)
                    .WithMany(p => p.CommercialFishingDocumentsDetailUploadedPhotograph)
                    .HasForeignKey(d => d.UploadedPhotographId)
                    .HasConstraintName("FK_CommercialFishingDocumentsDetail_UploadedDocument_PhotographID");
            });

            modelBuilder.Entity<CommercialFishingPaymentDetail>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CommercialFishingApplicationId).HasColumnName("CommercialFishingApplicationID");

                entity.Property(e => e.PaymentDetailId)
                    .HasColumnName("PaymentDetailID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.HasOne(d => d.CommercialFishingApplication)
                    .WithMany(p => p.CommercialFishingPaymentDetail)
                    .HasForeignKey(d => d.CommercialFishingApplicationId)
                    .HasConstraintName("FK_CommercialFishingPaymentDetail_CommercialFishingApplication");

                entity.HasOne(d => d.PaymentDetail)
                    .WithMany(p => p.CommercialFishingPaymentDetail)
                    .HasForeignKey(d => d.PaymentDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingPaymentDetail_PaymentDetail");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.CommercialFishingPaymentDetail)
                    .HasForeignKey(d => d.SubProcessId)
                    .HasConstraintName("FK_CommercialFishingPaymentDetail_MtSubProcess");
            });

            modelBuilder.Entity<CommercialFishingStatusChangeHistory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommercialFishingApplicationId).HasColumnName("CommercialFishingApplicationID");

                entity.Property(e => e.ModifiedByRoleId).HasColumnName("ModifiedByRoleID");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NotificationSmsbody)
                    .HasColumnName("NotificationSMSBody")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmsreceipients)
                    .HasColumnName("NotificationSMSReceipients")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmssent).HasColumnName("NotificationSMSSent");

                entity.Property(e => e.StatusIdfrom).HasColumnName("StatusIDFrom");

                entity.Property(e => e.StatusIdto).HasColumnName("StatusIDTo");

                entity.HasOne(d => d.CommercialFishingApplication)
                    .WithMany(p => p.CommercialFishingStatusChangeHistory)
                    .HasForeignKey(d => d.CommercialFishingApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CommercialFishingStatusChangeHistory_CommercialFishingApplication");
            });

            modelBuilder.Entity<CompanyStakeHolder>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DesignationId).HasColumnName("DesignationID");

                entity.Property(e => e.Email).HasMaxLength(250);

                entity.Property(e => e.Emirate).HasMaxLength(50);

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.MobileNumber).HasMaxLength(20);

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.Property(e => e.NationalityId).HasColumnName("NationalityID");

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.StakeHolderTypeId).HasColumnName("StakeHolderTypeID");

                entity.Property(e => e.WorkPhone).HasMaxLength(20);

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.CompanyStakeHolder)
                    .HasForeignKey(d => d.DesignationId)
                    .HasConstraintName("FK_CompanyStakeHolder_MtDesignation");

                entity.HasOne(d => d.Nationality)
                    .WithMany(p => p.CompanyStakeHolder)
                    .HasForeignKey(d => d.NationalityId)
                    .HasConstraintName("FK_CompanyStakeHolder_MtCountry");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.CompanyStakeHolder)
                    .HasForeignKey(d => d.ProfileId)
                    .HasConstraintName("FK_CompanyStakeHolder_Profile");

                entity.HasOne(d => d.StakeHolderType)
                    .WithMany(p => p.CompanyStakeHolder)
                    .HasForeignKey(d => d.StakeHolderTypeId)
                    .HasConstraintName("FK_CompanyStakeHolder_MtStakeHolderType");
            });

            modelBuilder.Entity<ConditionDeleted>(entity =>
            {
                entity.ToTable("Condition_Deleted");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Condition).HasMaxLength(200);

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.SectorId).HasColumnName("SectorID");

                entity.HasOne(d => d.Sector)
                    .WithMany(p => p.ConditionDeleted)
                    .HasForeignKey(d => d.SectorId)
                    .HasConstraintName("FK_Condition_MtSector");
            });

            modelBuilder.Entity<CtActivitySpecificQuestionnaire>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Activity)
                    .WithMany(p => p.CtActivitySpecificQuestionnaire)
                    .HasForeignKey(d => d.ActivityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtActivitySpecificQuestionnaire_MtActivity");

                entity.HasOne(d => d.ParentQuestionnaire)
                    .WithMany(p => p.InverseParentQuestionnaire)
                    .HasForeignKey(d => d.ParentQuestionnaireId)
                    .HasConstraintName("FK_CtActivitySpecificQuestionnaire_CtActivitySpecificQuestionnaire");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.CtActivitySpecificQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtActivitySpecificQuestionnaire_MtQuestionnaire");

                entity.HasOne(d => d.QuestionnaireType)
                    .WithMany(p => p.CtActivitySpecificQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireTypeId)
                    .HasConstraintName("FK_CtActivitySpecificQuestionnaire_MtQuestionnaireType");
            });

            modelBuilder.Entity<CtEqspermitCondition>(entity =>
            {
                entity.ToTable("CtEQSPermitCondition");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Activity)
                    .WithMany(p => p.CtEqspermitCondition)
                    .HasForeignKey(d => d.ActivityId)
                    .HasConstraintName("FK_CtEQSPermitCondition_MtActivity");

                entity.HasOne(d => d.PermitCondition)
                    .WithMany(p => p.CtEqspermitCondition)
                    .HasForeignKey(d => d.PermitConditionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtEQSPermitCondition_MtPermitCondition");
            });

            modelBuilder.Entity<CtEqsquestionnaire>(entity =>
            {
                entity.ToTable("CtEQSQuestionnaire");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ParentQuestionnaire)
                    .WithMany(p => p.InverseParentQuestionnaire)
                    .HasForeignKey(d => d.ParentQuestionnaireId)
                    .HasConstraintName("FK_CtEQSQuestionnaire_CtEQSQuestionnaire1");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.CtEqsquestionnaire)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtEQSQuestionnaire_MtQuestionnaire");

                entity.HasOne(d => d.QuestionnaireType)
                    .WithMany(p => p.CtEqsquestionnaire)
                    .HasForeignKey(d => d.QuestionnaireTypeId)
                    .HasConstraintName("FK_CtEQSQuestionnaire_MtQuestionnaireType");
            });

            modelBuilder.Entity<CtFee>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Fee).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.CtFee)
                    .HasForeignKey(d => d.SubProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Fee_MtSubProcess");
            });

            modelBuilder.Entity<CtGeneralQuestionnaire>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ParentQuestionnaire)
                    .WithMany(p => p.InverseParentQuestionnaire)
                    .HasForeignKey(d => d.ParentQuestionnaireId)
                    .HasConstraintName("FK_CtGeneralQuestionnaire_CtGeneralQuestionnaire");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.CtGeneralQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtGeneralQuestionnaire_MtQuestionnaire");

                entity.HasOne(d => d.QuestionnaireType)
                    .WithMany(p => p.CtGeneralQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireTypeId)
                    .HasConstraintName("FK_CtGeneralQuestionnaire_MtQuestionnaireType");
            });

            modelBuilder.Entity<CtPermitValidityDuration>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.CtPermitValidityDuration)
                    .HasForeignKey(d => d.SubProcessId)
                    .HasConstraintName("FK_CtPermitValidityDuration_MtSubProcess");
            });

            modelBuilder.Entity<CtProfileTypeRoleMenuMapping>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.MenuId).HasColumnName("MenuID");

                entity.Property(e => e.ProfileTypeId).HasColumnName("ProfileTypeID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.CtProfileTypeRoleMenuMapping)
                    .HasForeignKey(d => d.MenuId)
                    .HasConstraintName("FK_CtRolePageMapping_MtMenu_MenuID");

                entity.HasOne(d => d.ProfileType)
                    .WithMany(p => p.CtProfileTypeRoleMenuMapping)
                    .HasForeignKey(d => d.ProfileTypeId)
                    .HasConstraintName("FK_CtProfileTypeRoleMenuMapping_MtProfileType");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.CtProfileTypeRoleMenuMapping)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_CtRolePageMapping_MtRole");
            });

            modelBuilder.Entity<CtSectorSpecificQuestionnaire>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ParentQuestionnaire)
                    .WithMany(p => p.InverseParentQuestionnaire)
                    .HasForeignKey(d => d.ParentQuestionnaireId)
                    .HasConstraintName("FK_CtSectorSpecificQuestionnaire_CtSectorSpecificQuestionnaire");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.CtSectorSpecificQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtSectorSpecificQuestionnaire_MtQuestionnaire");

                entity.HasOne(d => d.QuestionnaireType)
                    .WithMany(p => p.CtSectorSpecificQuestionnaire)
                    .HasForeignKey(d => d.QuestionnaireTypeId)
                    .HasConstraintName("FK_CtSectorSpecificQuestionnaire_MtQuestionnaireType");

                entity.HasOne(d => d.Sector)
                    .WithMany(p => p.CtSectorSpecificQuestionnaire)
                    .HasForeignKey(d => d.SectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CtSectorSpecificQuestionnaire_MtSector");
            });

            modelBuilder.Entity<CtTeamMember>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.UserRoleMapping)
                    .WithMany(p => p.CtTeamMember)
                    .HasForeignKey(d => d.UserRoleMappingId)
                    .HasConstraintName("FK_CtTeamMember_CtUserRoleMapping");
            });

            modelBuilder.Entity<CtUserRoleMapping>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.CtUserRoleMapping)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_CtUserRoleMapping_MtRole");
            });

            modelBuilder.Entity<CustomerDeleted>(entity =>
            {
                entity.HasKey(e => e.CustomerId)
                    .HasName("PK_Customers");

                entity.ToTable("Customer_Deleted");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Area).HasMaxLength(100);

                entity.Property(e => e.Building).HasMaxLength(100);

                entity.Property(e => e.City).HasMaxLength(100);

                entity.Property(e => e.CommunicationTypeId).HasColumnName("CommunicationTypeID");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Dob)
                    .HasColumnName("DOB")
                    .HasColumnType("datetime");

                entity.Property(e => e.DocumentExpiryDate).HasColumnType("datetime");

                entity.Property(e => e.DocumentNumber).HasMaxLength(50);

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.Email).HasMaxLength(100);

                entity.Property(e => e.FaxNumber).HasMaxLength(20);

                entity.Property(e => e.FirstName).HasMaxLength(200);

                entity.Property(e => e.FirstNameAr)
                    .HasColumnName("FirstNameAR")
                    .HasMaxLength(200);

                entity.Property(e => e.Gender).HasMaxLength(6);

                entity.Property(e => e.IssuedById).HasColumnName("IssuedByID");

                entity.Property(e => e.LastName).HasMaxLength(200);

                entity.Property(e => e.LastNameAr)
                    .HasColumnName("LastNameAR")
                    .HasMaxLength(200);

                entity.Property(e => e.MiddleName).HasMaxLength(200);

                entity.Property(e => e.MiddleNameAr)
                    .HasColumnName("MiddleNameAR")
                    .HasMaxLength(200);

                entity.Property(e => e.MobileNumber).HasMaxLength(20);

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.NationalityId).HasColumnName("NationalityID");

                entity.Property(e => e.Pobox)
                    .HasColumnName("POBOX")
                    .HasMaxLength(20);

                entity.Property(e => e.Profile).HasMaxLength(50);

                entity.Property(e => e.State).HasMaxLength(100);

                entity.Property(e => e.Street).HasMaxLength(100);

                entity.Property(e => e.Suffix).HasMaxLength(20);

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.UserTypeId).HasColumnName("UserTypeID");
            });

            modelBuilder.Entity<CustomerIndividualDeleted>(entity =>
            {
                entity.ToTable("CustomerIndividual_Deleted");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.ContactMobileNumber).HasMaxLength(15);

                entity.Property(e => e.ContactPersonName).HasMaxLength(250);

                entity.Property(e => e.ContactPhoneNumber).HasMaxLength(15);

                entity.Property(e => e.UploadEmiratesId).HasColumnName("UploadEmiratesID");

                entity.Property(e => e.UploadedDocId1).HasColumnName("UploadedDocID1");

                entity.Property(e => e.UploadedDocId2).HasColumnName("UploadedDocID2");

                entity.Property(e => e.UploadedDocId3).HasColumnName("UploadedDocID3");

                entity.Property(e => e.UploadedDocId4).HasColumnName("UploadedDocID4");

                entity.Property(e => e.UploadedDocId5).HasColumnName("UploadedDocID5");

                entity.Property(e => e.UploadedDocName1).HasMaxLength(250);

                entity.Property(e => e.UploadedDocName2).HasMaxLength(250);

                entity.Property(e => e.UploadedDocName3).HasMaxLength(250);

                entity.Property(e => e.UploadedDocName4).HasMaxLength(250);

                entity.Property(e => e.UploadedDocName5).HasMaxLength(250);
            });

            modelBuilder.Entity<DecisionStatusDeleted>(entity =>
            {
                entity.ToTable("DecisionStatus_Deleted");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Decision).HasMaxLength(250);
            });

            modelBuilder.Entity<EmailMasterDeleted>(entity =>
            {
                entity.HasKey(e => e.EmailMasterId)
                    .HasName("PK_EmailMasters");

                entity.ToTable("EmailMaster_Deleted");

                entity.Property(e => e.EmailMasterId).HasColumnName("EmailMasterID");

                entity.Property(e => e.EmailTitle).HasMaxLength(1000);
            });

            modelBuilder.Entity<EqsactivityMapping>(entity =>
            {
                entity.ToTable("EQSActivityMapping");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsactivityMapping)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSActivityMapping_EQSApplication");
            });

            modelBuilder.Entity<EqsadministrativeDetails>(entity =>
            {
                entity.ToTable("EQSAdministrativeDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CompanyNameArabic).HasMaxLength(250);

                entity.Property(e => e.CompanyNameEnglish).HasMaxLength(250);

                entity.Property(e => e.CompanyPoboxNumber)
                    .HasColumnName("CompanyPOBoxNumber")
                    .HasMaxLength(10);

                entity.Property(e => e.CompanyTelephoneNumber).HasMaxLength(30);

                entity.Property(e => e.EmailId).HasMaxLength(200);

                entity.Property(e => e.EmirateId).HasMaxLength(40);

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ManagerMobilePhone).HasMaxLength(30);

                entity.Property(e => e.ManagerName).HasMaxLength(250);

                entity.Property(e => e.MobilePhone).HasMaxLength(30);

                entity.Property(e => e.OwnerNameArabic).HasMaxLength(250);

                entity.Property(e => e.OwnerNameEnglish).HasMaxLength(250);

                entity.Property(e => e.TradeLicenseNumber).HasMaxLength(40);
            });

            modelBuilder.Entity<Eqsapplication>(entity =>
            {
                entity.ToTable("EQSApplication");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ParentEqsapplicationId).HasColumnName("ParentEQSApplicationId");

                entity.Property(e => e.TimeStamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.Eqsapplication)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplication_Application");

                entity.HasOne(d => d.ApplicationWithRole)
                    .WithMany(p => p.Eqsapplication)
                    .HasForeignKey(d => d.ApplicationWithRoleId)
                    .HasConstraintName("FK_EQSApplication_MtRole");

                entity.HasOne(d => d.ApplicationWithUser)
                    .WithMany(p => p.EqsapplicationApplicationWithUser)
                    .HasForeignKey(d => d.ApplicationWithUserId);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.EqsapplicationCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.ParentEqsapplication)
                    .WithMany(p => p.InverseParentEqsapplication)
                    .HasForeignKey(d => d.ParentEqsapplicationId)
                    .HasConstraintName("FK_EQSApplication_EQSApplication");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.Eqsapplication)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplication_MtStatus");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.Eqsapplication)
                    .HasForeignKey(d => d.SubProcessId)
                    .HasConstraintName("FK_EQSApplication_MtSubProcess");
            });

            modelBuilder.Entity<EqsapplicationAssistanceComments>(entity =>
            {
                entity.ToTable("EQSApplicationAssistanceComments");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Comments).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsrequestForAssistanceId).HasColumnName("EQSRequestForAssistanceId");

                entity.HasOne(d => d.EqsrequestForAssistance)
                    .WithMany(p => p.EqsapplicationAssistanceComments)
                    .HasForeignKey(d => d.EqsrequestForAssistanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationAssistanceComments_EQSRequestForAssistance");
            });

            modelBuilder.Entity<EqsapplicationComments>(entity =>
            {
                entity.ToTable("EQSApplicationComments");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ExternalComment).HasMaxLength(1000);

                entity.Property(e => e.InternalComment).HasMaxLength(1000);

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationComments)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSApplicationComments_EQSApplication");
            });

            modelBuilder.Entity<EqsapplicationDocumentsUpload>(entity =>
            {
                entity.ToTable("EQSApplicationDocumentsUpload");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.EqsapplicationDocumentsUpload)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPDocumentsUploaded_EQSApplication");
            });

            modelBuilder.Entity<EqsapplicationPermitCondition>(entity =>
            {
                entity.ToTable("EQSApplicationPermitCondition");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.Comment).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationPermitCondition)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationPermitCondition_EQSApplication");

                entity.HasOne(d => d.PermitCondition)
                    .WithMany(p => p.EqsapplicationPermitCondition)
                    .HasForeignKey(d => d.PermitConditionId)
                    .HasConstraintName("FK_EQSApplicationPermitCondition_PermitCondition");
            });

            modelBuilder.Entity<EqsapplicationQuestionnaireAnswers>(entity =>
            {
                entity.ToTable("EQSApplicationQuestionnaireAnswers");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Comments).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationQuestionnaireAnswers)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSApplicationQuestionnaireAnswers_EQSApplication");
            });

            modelBuilder.Entity<EqsapplicationReport>(entity =>
            {
                entity.ToTable("EQSApplicationReport");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.Comment).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.EqsapplicationReport)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationReport_User");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationReport)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationReport_EQSApplication");

                entity.HasOne(d => d.ReportType)
                    .WithMany(p => p.EqsapplicationReport)
                    .HasForeignKey(d => d.ReportTypeId)
                    .HasConstraintName("FK_EQSApplicationReport_ReportType");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.EqsapplicationReport)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationReport_MtStatus");
            });

            modelBuilder.Entity<EqsapplicationReportStatusHistory>(entity =>
            {
                entity.ToTable("EQSApplicationReportStatusHistory");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comment).HasMaxLength(1000);

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationReportStatusHistory)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSApplicationReportStatusHistory_EQSApplication");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.EqsapplicationReportStatusHistory)
                    .HasForeignKey(d => d.ModifiedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationReportStatusHistory_User");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.EqsapplicationReportStatusHistory)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_EQSApplicationReportStatusHistory_MtRole");

                entity.HasOne(d => d.StatusFrom)
                    .WithMany(p => p.EqsapplicationReportStatusHistoryStatusFrom)
                    .HasForeignKey(d => d.StatusFromId);

                entity.HasOne(d => d.StatusTo)
                    .WithMany(p => p.EqsapplicationReportStatusHistoryStatusTo)
                    .HasForeignKey(d => d.StatusToId);
            });

            modelBuilder.Entity<EqsapplicationStatusHistory>(entity =>
            {
                entity.ToTable("EQSApplicationStatusHistory");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comment).HasMaxLength(1000);

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationStatusHistory)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSApplicationStatusHistory_EQSApplication");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.EqsapplicationStatusHistory)
                    .HasForeignKey(d => d.ModifiedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStatusHistory_User");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.EqsapplicationStatusHistory)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_EQSApplicationStatusHistory_MtRole");

                entity.HasOne(d => d.StatusFrom)
                    .WithMany(p => p.EqsapplicationStatusHistoryStatusFrom)
                    .HasForeignKey(d => d.StatusFromId);

                entity.HasOne(d => d.StatusTo)
                    .WithMany(p => p.EqsapplicationStatusHistoryStatusTo)
                    .HasForeignKey(d => d.StatusToId);
            });

            modelBuilder.Entity<EqsapplicationStudy>(entity =>
            {
                entity.ToTable("EQSApplicationStudy");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.Comments).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeminimusOverrideJustification).HasMaxLength(1000);

                entity.Property(e => e.EcocompanyScore).HasColumnName("ECOCompanyScore");

                entity.Property(e => e.EcocompnayId).HasColumnName("ECOCompnayID");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.EqsclassId).HasColumnName("EQSClassId");

                entity.Property(e => e.EqsgradeId).HasColumnName("EQSGradeId");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.EqsapplicationStudy)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStudy_User");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationStudy)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStudy_EQSApplication");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.EqsapplicationStudy)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("FK_EQSApplicationStudy_MtStatus");

                entity.HasOne(d => d.StudyType)
                    .WithMany(p => p.EqsapplicationStudy)
                    .HasForeignKey(d => d.StudyTypeId)
                    .HasConstraintName("FK_EQSApplicationStudy_StudyType");
            });

            modelBuilder.Entity<EqsapplicationStudyDocumentUpload>(entity =>
            {
                entity.ToTable("EQSApplicationStudyDocumentUpload");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationStudyId).HasColumnName("EQSApplicationStudyId");

                entity.HasOne(d => d.EqsapplicationStudy)
                    .WithMany(p => p.EqsapplicationStudyDocumentUpload)
                    .HasForeignKey(d => d.EqsapplicationStudyId)
                    .HasConstraintName("FK_EQSApplicationStudyDocumentUpload_EQSApplicationStudy");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.EqsapplicationStudyDocumentUpload)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStudyDocumentUpload_UploadedDocument");
            });

            modelBuilder.Entity<EqsapplicationStudyReviewCriteria>(entity =>
            {
                entity.ToTable("EQSApplicationStudyReviewCriteria");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationStudyId).HasColumnName("EQSApplicationStudyId");

                entity.HasOne(d => d.EqsapplicationStudy)
                    .WithMany(p => p.EqsapplicationStudyReviewCriteria)
                    .HasForeignKey(d => d.EqsapplicationStudyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStudyReviewCriteria_EQSApplicationStudy");
            });

            modelBuilder.Entity<EqsapplicationStudyStatusHistory>(entity =>
            {
                entity.ToTable("EQSApplicationStudyStatusHistory");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comment).HasMaxLength(1000);

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.EqsapplicationStudyStatusHistory)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .HasConstraintName("FK_EQSApplicationStudyStatusHistory_EQSApplication");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.EqsapplicationStudyStatusHistory)
                    .HasForeignKey(d => d.ModifiedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSApplicationStudyStatusHistory_User");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.EqsapplicationStudyStatusHistory)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_EQSApplicationStudyStatusHistory_MtRole");

                entity.HasOne(d => d.StatusFrom)
                    .WithMany(p => p.EqsapplicationStudyStatusHistoryStatusFrom)
                    .HasForeignKey(d => d.StatusFromId);

                entity.HasOne(d => d.StatusTo)
                    .WithMany(p => p.EqsapplicationStudyStatusHistoryStatusTo)
                    .HasForeignKey(d => d.StatusToId);
            });

            modelBuilder.Entity<EqsinternalForm>(entity =>
            {
                entity.ToTable("EQSInternalForm");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.EqsinternalForm)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_EQSInternalForm_EQSApplication");
            });

            modelBuilder.Entity<EqsrequestForAssistance>(entity =>
            {
                entity.ToTable("EQSRequestForAssistance");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comments).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DueDate).HasColumnType("datetime");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.Property(e => e.EqsassistanceTypeId).HasColumnName("EQSAssistanceTypeId");

                entity.HasOne(d => d.AssistanceRequestedFromUser)
                    .WithMany(p => p.EqsrequestForAssistanceAssistanceRequestedFromUser)
                    .HasForeignKey(d => d.AssistanceRequestedFromUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.EqsrequestForAssistanceCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.EqsrequestForAssistance)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_EQSRequestForAssistance_EQSApplication");

                entity.HasOne(d => d.EqsassistanceType)
                    .WithMany(p => p.EqsrequestForAssistance)
                    .HasForeignKey(d => d.EqsassistanceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EQSRequestForAssistance_EQSAssistanceType");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.EqsrequestForAssistance)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("FK_EQSRequestForAssistance_Status");
            });

            modelBuilder.Entity<EqstechnicalDetails>(entity =>
            {
                entity.ToTable("EQSTechnicalDetails");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.ProjectDetails).HasMaxLength(1000);

                entity.Property(e => e.ProjectSummary).HasMaxLength(500);
            });

            modelBuilder.Entity<ErrorDeleted>(entity =>
            {
                entity.ToTable("Error_Deleted");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);
            });

            modelBuilder.Entity<Exceptionlog>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Exception)
                    .HasColumnName("exception")
                    .HasMaxLength(3600)
                    .IsUnicode(false);

                entity.Property(e => e.Level)
                    .IsRequired()
                    .HasColumnName("level")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Message)
                    .IsRequired()
                    .HasColumnName("message")
                    .HasMaxLength(3600)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .HasColumnName("timestamp")
                    .HasColumnType("datetime");

                entity.Property(e => e.Userid).HasColumnName("userid");
            });

            modelBuilder.Entity<GroundWaterApplication>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DistrictSectorId).HasColumnName("DistrictSectorID");

                entity.Property(e => e.Easting).HasMaxLength(50);

                entity.Property(e => e.GeographicalDivisionId).HasColumnName("GeographicalDivisionID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsDraft)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.Northing).HasMaxLength(50);

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.PropertyArea).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.PropertyName).HasMaxLength(500);

                entity.Property(e => e.PropertyTypeId).HasColumnName("PropertyTypeID");

                entity.Property(e => e.UploadedPropertyOwnershipDocId).HasColumnName("UploadedPropertyOwnershipDocID");

                entity.Property(e => e.UploadedSiteMapDocId).HasColumnName("UploadedSiteMapDocID");

                entity.Property(e => e.ValidFrom).HasColumnType("date");

                entity.Property(e => e.ValidTo).HasColumnType("date");

                entity.HasOne(d => d.DistrictSector)
                    .WithMany(p => p.GroundWaterApplication)
                    .HasForeignKey(d => d.DistrictSectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterApplication_MtDistrictSector");

                entity.HasOne(d => d.GeographicalDivision)
                    .WithMany(p => p.GroundWaterApplication)
                    .HasForeignKey(d => d.GeographicalDivisionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterApplication_MtGeographicalDivision");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.GroundWaterApplication)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterApplication_Profile");

                entity.HasOne(d => d.PropertyType)
                    .WithMany(p => p.GroundWaterApplication)
                    .HasForeignKey(d => d.PropertyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterApplication_MtPropertyType");

                entity.HasOne(d => d.UploadedPropertyOwnershipDoc)
                    .WithMany(p => p.GroundWaterApplicationUploadedPropertyOwnershipDoc)
                    .HasForeignKey(d => d.UploadedPropertyOwnershipDocId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.UploadedSiteMapDoc)
                    .WithMany(p => p.GroundWaterApplicationUploadedSiteMapDoc)
                    .HasForeignKey(d => d.UploadedSiteMapDocId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<GroundWaterComment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.GroundWaterApplicationId).HasColumnName("GroundWaterApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UploadedDocumentId).HasColumnName("UploadedDocumentID");

                entity.HasOne(d => d.GroundWaterApplication)
                    .WithMany(p => p.GroundWaterComment)
                    .HasForeignKey(d => d.GroundWaterApplicationId)
                    .HasConstraintName("FK_GroundWaterComment_GroundWaterApplication");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.GroundWaterComment)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_GroundWaterComment_MtRole");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.GroundWaterComment)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .HasConstraintName("FK_GroundWaterComment_UploadedDocument");
            });

            modelBuilder.Entity<GroundWaterCustomerContractorMapping>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.GroundWaterApplicationId).HasColumnName("GroundWaterApplicationID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.ProfileContractId).HasColumnName("ProfileContractID");

                entity.HasOne(d => d.GroundWaterApplication)
                    .WithMany(p => p.GroundWaterCustomerContractorMapping)
                    .HasForeignKey(d => d.GroundWaterApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterCustomerContractorMapping_GroundWaterApplication");

                entity.HasOne(d => d.ProfileContract)
                    .WithMany(p => p.GroundWaterCustomerContractorMapping)
                    .HasForeignKey(d => d.ProfileContractId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GroundWaterCustomerContractorMapping_ProfileContractDetail");
            });

            modelBuilder.Entity<GroundWaterExistingWell>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Easting).HasMaxLength(25);

                entity.Property(e => e.GroundWaterApplicationId).HasColumnName("GroundWaterApplicationID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.Northing).HasMaxLength(25);

                entity.Property(e => e.OperationStatusId).HasColumnName("OperationStatusID");

                entity.Property(e => e.WellCode).HasMaxLength(25);

                entity.Property(e => e.WellLocationId).HasColumnName("WellLocationID");

                entity.Property(e => e.WellProductionStatusId).HasColumnName("WellProductionStatusID");

                entity.Property(e => e.WellPurposeId).HasColumnName("WellPurposeID");

                entity.Property(e => e.WellZoneId).HasColumnName("WellZoneID");

                entity.HasOne(d => d.GroundWaterApplication)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.GroundWaterApplicationId)
                    .HasConstraintName("FK_GroundWaterExistingWell_GroundWaterApplication");

                entity.HasOne(d => d.OperationStatus)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.OperationStatusId)
                    .HasConstraintName("FK_GroundWaterExistingWell_MtGroundWaterOperationalStatus");

                entity.HasOne(d => d.WellLocation)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.WellLocationId)
                    .HasConstraintName("FK_GroundWaterExistingWell_MtGroundWaterWellLocation");

                entity.HasOne(d => d.WellProductionStatus)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.WellProductionStatusId)
                    .HasConstraintName("FK_GroundWaterExistingWell_MtGroundWaterWellProductionStatus");

                entity.HasOne(d => d.WellPurpose)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.WellPurposeId)
                    .HasConstraintName("FK_GroundWaterExistingWell_MtGroundWaterWellPurpose");

                entity.HasOne(d => d.WellZone)
                    .WithMany(p => p.GroundWaterExistingWell)
                    .HasForeignKey(d => d.WellZoneId)
                    .HasConstraintName("FK_GroundWaterExistingWell_MtZone");
            });

            modelBuilder.Entity<GroundWaterPayment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.GroundWaterApplicationId).HasColumnName("GroundWaterApplicationID");

                entity.Property(e => e.PaymentDetailId).HasColumnName("PaymentDetailID");

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.HasOne(d => d.GroundWaterApplication)
                    .WithMany(p => p.GroundWaterPayment)
                    .HasForeignKey(d => d.GroundWaterApplicationId)
                    .HasConstraintName("FK_GroundWaterPayment_GroundWaterApplication");

                entity.HasOne(d => d.PaymentDetail)
                    .WithMany(p => p.GroundWaterPayment)
                    .HasForeignKey(d => d.PaymentDetailId)
                    .HasConstraintName("FK_GroundWaterPayment_PaymentDetail");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.GroundWaterPayment)
                    .HasForeignKey(d => d.SubProcessId)
                    .HasConstraintName("FK_GroundWaterPayment_MtSubProcess");
            });

            modelBuilder.Entity<GroundWaterStatusChangeHistory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.GroundWaterApplicationId).HasColumnName("GroundWaterApplicationID");

                entity.Property(e => e.ModifiedByRoleId).HasColumnName("ModifiedByRoleID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NotificationSmsreceipients).HasColumnName("NotificationSMSReceipients");

                entity.Property(e => e.NotificationSmssent).HasColumnName("NotificationSMSSent");

                entity.Property(e => e.StatusIdfrom).HasColumnName("StatusIDFrom");

                entity.Property(e => e.StatusIdto).HasColumnName("StatusIDTo");

                entity.Property(e => e.TypeofPermit).HasMaxLength(250);

                entity.HasOne(d => d.GroundWaterApplication)
                    .WithMany(p => p.GroundWaterStatusChangeHistory)
                    .HasForeignKey(d => d.GroundWaterApplicationId)
                    .HasConstraintName("FK_GroundWaterStatusChangeHistory_GroundWaterApplication");

                entity.HasOne(d => d.ModifiedByRole)
                    .WithMany(p => p.GroundWaterStatusChangeHistory)
                    .HasForeignKey(d => d.ModifiedByRoleId)
                    .HasConstraintName("FK_GroundWaterStatusChangeHistory_MtRole");
            });

            modelBuilder.Entity<IdphousingMallProjectDetails>(entity =>
            {
                entity.ToTable("IDPHousingMallProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdphousingMallProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPHousingMallProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdpliveStockAgricultureProjectDetails>(entity =>
            {
                entity.ToTable("IDPLiveStockAgricultureProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdpliveStockAgricultureProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPLiveStockAgricultureProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdpmarineDreadgingProjectDetails>(entity =>
            {
                entity.ToTable("IDPMarineDreadgingProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdpmarineDreadgingProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPMarineDreadgingProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdpotherProjectDetails>(entity =>
            {
                entity.ToTable("IDPOtherProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdpotherProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPOtherProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdppipelineElectricCableProjectDetails>(entity =>
            {
                entity.ToTable("IDPPipelineElectricCableProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdppipelineElectricCableProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPPipelineElectricCableProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdpprojectClassificationMapping>(entity =>
            {
                entity.ToTable("IDPProjectClassificationMapping");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.Property(e => e.ProjectClassificationId).HasColumnName("ProjectClassificationID");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdpprojectClassificationMapping)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPProjectClassificationMapping_EQSApplication");

                entity.HasOne(d => d.ProjectClassification)
                    .WithMany(p => p.IdpprojectClassificationMapping)
                    .HasForeignKey(d => d.ProjectClassificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_IDPProjectClassificationMapping_MtProjectClassification");
            });

            modelBuilder.Entity<IdpquestionnaireAnswer>(entity =>
            {
                entity.ToTable("IDPQuestionnaireAnswer");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comments).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicationId).HasColumnName("EQSApplicationId");

                entity.Property(e => e.EqsquestionnaireId).HasColumnName("EQSQuestionnaireId");

                entity.HasOne(d => d.Eqsapplication)
                    .WithMany(p => p.IdpquestionnaireAnswer)
                    .HasForeignKey(d => d.EqsapplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_IDPQuestionnaireAnswer_EQSApplication");

                entity.HasOne(d => d.Eqsquestionnaire)
                    .WithMany(p => p.IdpquestionnaireAnswer)
                    .HasForeignKey(d => d.EqsquestionnaireId)
                    .HasConstraintName("FK_IDPQuestionnaireAnswer_IDPQuestionnaireAnswer");
            });

            modelBuilder.Entity<IdptourismLeisureProjectDetails>(entity =>
            {
                entity.ToTable("IDPTourismLeisureProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdptourismLeisureProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPTourismLeisureProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<IdptransportProjectDetails>(entity =>
            {
                entity.ToTable("IDPTransportProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.Property(e => e.TotalLength).HasColumnType("decimal(6, 2)");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdptransportProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPTransportProjectDetails_EQSApplication");

                entity.HasOne(d => d.ProjectSubClassificationNavigation)
                    .WithMany(p => p.IdptransportProjectDetailsProjectSubClassificationNavigation)
                    .HasForeignKey(d => d.ProjectSubClassification);

                entity.HasOne(d => d.SubClasificationOfSubProjectNavigation)
                    .WithMany(p => p.IdptransportProjectDetailsSubClasificationOfSubProjectNavigation)
                    .HasForeignKey(d => d.SubClasificationOfSubProject)
                    .HasConstraintName("FK_IDPTransportProjectDetails_MtProjectClassification");
            });

            modelBuilder.Entity<IdpwasteTreatementRelatedProjectDetails>(entity =>
            {
                entity.ToTable("IDPWasteTreatementRelatedProjectDetails");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EqsapplicaitonId).HasColumnName("EQSApplicaitonId");

                entity.HasOne(d => d.Eqsapplicaiton)
                    .WithMany(p => p.IdpwasteTreatementRelatedProjectDetails)
                    .HasForeignKey(d => d.EqsapplicaitonId)
                    .HasConstraintName("FK_IDPWasteTreatementRelatedProjectDetails_EQSApplication");
            });

            modelBuilder.Entity<Inbox>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Message).HasMaxLength(400);

                entity.Property(e => e.Subject).HasMaxLength(2000);
            });

            modelBuilder.Entity<MtAccessLevel>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AccessLevel).HasMaxLength(10);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtAction>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtActionLanguage>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.LanguageId })
                    .HasName("PK_ActionLanguage");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtActionLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtActionLanguage_MtLanguage");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.MtActionLanguage)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtActionLanguage_MtAction");
            });

            modelBuilder.Entity<MtActivity>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ActivityCode).HasMaxLength(50);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");
            });

            modelBuilder.Entity<MtActivityLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ActivityId, e.LanguageId });

                entity.Property(e => e.ActivityId).HasColumnName("ActivityID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(1000);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Activity)
                    .WithMany(p => p.MtActivityLanguage)
                    .HasForeignKey(d => d.ActivityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtActivityLanguage_MtActivity");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtActivityLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtActivityLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtApplicationNumberConfiguration>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationPreFix).HasMaxLength(3);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.TypeOfPermit).HasMaxLength(250);
            });

            modelBuilder.Entity<MtBoatBodyType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtBoatBodyTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.BoatBodyTypeId, e.LanguageId });

                entity.Property(e => e.BoatBodyTypeId).HasColumnName("BoatBodyTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.HasOne(d => d.BoatBodyType)
                    .WithMany(p => p.MtBoatBodyTypeLanguage)
                    .HasForeignKey(d => d.BoatBodyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtBoatBodyTypeLanguage_MtBoatBodyType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtBoatBodyTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtBoatBodyTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtBoatType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtBoatTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.BoatTypeId, e.LanguageId });

                entity.Property(e => e.BoatTypeId).HasColumnName("BoatTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.HasOne(d => d.BoatType)
                    .WithMany(p => p.MtBoatTypeLanguage)
                    .HasForeignKey(d => d.BoatTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtBoatTypeLanguage_MtBoatType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtBoatTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtBoatTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtCity>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtCityLanguage>(entity =>
            {
                entity.HasKey(e => new { e.CityId, e.LanguageId });

                entity.Property(e => e.CityId).HasColumnName("CityID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.City)
                    .WithMany(p => p.MtCityLanguage)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCityLanguage_MtCity");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtCityLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCityLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtCommunicationType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtCommunicationTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.CommunicationTypeId, e.LanguageId });

                entity.Property(e => e.CommunicationTypeId).HasColumnName("CommunicationTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.CommunicationType)
                    .WithMany(p => p.MtCommunicationTypeLanguage)
                    .HasForeignKey(d => d.CommunicationTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCommunicationTypeLanguage_MtCommunicationType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtCommunicationTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCommunicationTypeLanguage_Mtlanguage");
            });

            modelBuilder.Entity<MtCompanyDelete>(entity =>
            {
                entity.ToTable("MtCompany_Delete");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ceo)
                    .HasColumnName("CEO")
                    .HasMaxLength(250);

                entity.Property(e => e.ChamberofCommerceDocId).HasColumnName("ChamberofCommerceDocID");

                entity.Property(e => e.CompanyNameAr)
                    .HasColumnName("CompanyNameAR")
                    .HasMaxLength(500);

                entity.Property(e => e.CompanyNameEn)
                    .HasColumnName("CompanyNameEN")
                    .HasMaxLength(500);

                entity.Property(e => e.CompanyTypeId).HasColumnName("CompanyTypeID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Designation).HasMaxLength(250);

                entity.Property(e => e.EmiratesIddocId).HasColumnName("EmiratesIDDocID");

                entity.Property(e => e.EstablishedOn).HasColumnType("date");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LicenseDocId).HasColumnName("LicenseDocID");

                entity.Property(e => e.LicenseNumber).HasMaxLength(50);

                entity.Property(e => e.LogoDocId).HasColumnName("LogoDocID");

                entity.Property(e => e.ManagerName).HasMaxLength(250);

                entity.Property(e => e.NatureofBusinessId).HasColumnName("NatureofBusinessID");

                entity.Property(e => e.PlaceofIssueId).HasColumnName("PlaceofIssueID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.ValidFrom).HasColumnType("date");

                entity.Property(e => e.ValidTo).HasColumnType("date");

                entity.HasOne(d => d.ChamberofCommerceDoc)
                    .WithMany(p => p.MtCompanyDeleteChamberofCommerceDoc)
                    .HasForeignKey(d => d.ChamberofCommerceDocId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_UploadedDocument_ChamberOfCommerceDoc");

                entity.HasOne(d => d.EmiratesIddoc)
                    .WithMany(p => p.MtCompanyDeleteEmiratesIddoc)
                    .HasForeignKey(d => d.EmiratesIddocId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_UploadedDocument_EmiratesIDDoc");

                entity.HasOne(d => d.LicenseDoc)
                    .WithMany(p => p.MtCompanyDeleteLicenseDoc)
                    .HasForeignKey(d => d.LicenseDocId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_UploadedDocument_License");

                entity.HasOne(d => d.LogoDoc)
                    .WithMany(p => p.MtCompanyDeleteLogoDoc)
                    .HasForeignKey(d => d.LogoDocId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_UploadedDocument_LogoDoc");

                entity.HasOne(d => d.NatureofBusiness)
                    .WithMany(p => p.MtCompanyDelete)
                    .HasForeignKey(d => d.NatureofBusinessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_MtNatureOfBusiness");

                entity.HasOne(d => d.PlaceofIssue)
                    .WithMany(p => p.MtCompanyDelete)
                    .HasForeignKey(d => d.PlaceofIssueId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompany_MtCountry");
            });

            modelBuilder.Entity<MtCompanyType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtCompanyTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.CompanyTypeId, e.LanguageId });

                entity.Property(e => e.CompanyTypeId).HasColumnName("CompanyTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.HasOne(d => d.CompanyType)
                    .WithMany(p => p.MtCompanyTypeLanguage)
                    .HasForeignKey(d => d.CompanyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompanyTypeLanguage_MtCompanyType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtCompanyTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCompanyTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtCompareOperator>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtCountry>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CountryIsocode)
                    .HasColumnName("CountryISOCode")
                    .HasMaxLength(20);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.PhoneCountryCode).HasMaxLength(20);

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtCountryLanguage>(entity =>
            {
                entity.HasKey(e => new { e.CountryId, e.LanguageId });

                entity.Property(e => e.CountryId).HasColumnName("CountryID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.MtCountryLanguage)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCountryLanguage_MtCountry");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtCountryLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtCountryLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtDeliveryType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtDeliveryTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.DeliveryTypeId, e.LanguageId })
                    .HasName("PK_MtDeliveryLanguage");

                entity.Property(e => e.DeliveryTypeId).HasColumnName("DeliveryTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.DeliveryType)
                    .WithMany(p => p.MtDeliveryTypeLanguage)
                    .HasForeignKey(d => d.DeliveryTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDeliveryTypeLanguage_MtDeliveryType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtDeliveryTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDeliveryTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtDepartment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");
            });

            modelBuilder.Entity<MtDepartmentLanguage>(entity =>
            {
                entity.HasKey(e => new { e.DepartmentId, e.LanguageId });

                entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.MtDepartmentLanguage)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDepartmentLanguage_MtDepartment");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtDepartmentLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDepartmentLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtDesignation>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtDesignationLanguage>(entity =>
            {
                entity.HasKey(e => new { e.DesignationId, e.LanguageId });

                entity.Property(e => e.DesignationId).HasColumnName("DesignationID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.MtDesignationLanguage)
                    .HasForeignKey(d => d.DesignationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDesignationLanguage_MtDesignation");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtDesignationLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDesignationLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtDistrictSector>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.GeographicalDivisionId).HasColumnName("GeographicalDivisionID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IsDistrict)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.GeographicalDivision)
                    .WithMany(p => p.MtDistrictSector)
                    .HasForeignKey(d => d.GeographicalDivisionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDistrictSector_MtGeographicalDivision");
            });

            modelBuilder.Entity<MtDistrictSectorLanguage>(entity =>
            {
                entity.HasKey(e => new { e.DistrictSectorId, e.LanguageId });

                entity.Property(e => e.DistrictSectorId).HasColumnName("DistrictSectorID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.DistrictSector)
                    .WithMany(p => p.MtDistrictSectorLanguage)
                    .HasForeignKey(d => d.DistrictSectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDistrictSectorLanguage_MtDistrictSector");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtDistrictSectorLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDistrictSectorLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtDocumentType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DocumentType).HasMaxLength(250);

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtDocumentTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.DocumentTypeId, e.LanguageId });

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.DocumentType)
                    .WithMany(p => p.MtDocumentTypeLanguage)
                    .HasForeignKey(d => d.DocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDocumentTypeLanguage_MtDocumentType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtDocumentTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtDocumentTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEmirateState>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtEmirateStateLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EmirateStateId, e.LanguageId });

                entity.Property(e => e.EmirateStateId).HasColumnName("EmirateStateID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(200);

                entity.HasOne(d => d.EmirateState)
                    .WithMany(p => p.MtEmirateStateLanguage)
                    .HasForeignKey(d => d.EmirateStateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEmirateStateLanguage_MtEmirateState");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEmirateStateLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEmirateStateLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsassistanceType>(entity =>
            {
                entity.ToTable("MtEQSAssistanceType");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtEqsassistanceTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EqsassistanceTypeId, e.LanguageId });

                entity.ToTable("MtEQSAssistanceTypeLanguage");

                entity.Property(e => e.EqsassistanceTypeId).HasColumnName("EQSAssistanceTypeId");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(255);

                entity.HasOne(d => d.EqsassistanceType)
                    .WithMany(p => p.MtEqsassistanceTypeLanguage)
                    .HasForeignKey(d => d.EqsassistanceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSAssistanceTypeLanguage_MtEQSAssistanceType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEqsassistanceTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSAssistanceTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsclass>(entity =>
            {
                entity.ToTable("MtEQSClass");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtEqsclassLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EqsclassId, e.LanguageId });

                entity.ToTable("MtEQSClassLanguage");

                entity.Property(e => e.EqsclassId).HasColumnName("EQSClassId");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Eqsclass)
                    .WithMany(p => p.MtEqsclassLanguage)
                    .HasForeignKey(d => d.EqsclassId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSClassLanguage_MtEQSClass");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEqsclassLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSClassLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsclassReviewCriteria>(entity =>
            {
                entity.ToTable("MtEQSClassReviewCriteria");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<MtEqsclassReviewCriteriaLanguage>(entity =>
            {
                entity.HasKey(e => new { e.Eqsclass2ReviewCriteriaId, e.LangaugeId })
                    .HasName("PK_MtEQSClass2ReviewCriteriaLanguage");

                entity.ToTable("MtEQSClassReviewCriteriaLanguage");

                entity.Property(e => e.Eqsclass2ReviewCriteriaId).HasColumnName("EQSClass2ReviewCriteriaId");

                entity.Property(e => e.Criteria).HasMaxLength(500);

                entity.HasOne(d => d.Eqsclass2ReviewCriteria)
                    .WithMany(p => p.MtEqsclassReviewCriteriaLanguage)
                    .HasForeignKey(d => d.Eqsclass2ReviewCriteriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSClass2ReviewCriteriaLanguage_MtEQSClass2ReviewCriteria");

                entity.HasOne(d => d.Langauge)
                    .WithMany(p => p.MtEqsclassReviewCriteriaLanguage)
                    .HasForeignKey(d => d.LangaugeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSClass2ReviewCriteriaLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsgrade>(entity =>
            {
                entity.ToTable("MtEQSGrade");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtEqsgradeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EqsgradeId, e.LanguageId });

                entity.ToTable("MtEQSGradeLanguage");

                entity.Property(e => e.EqsgradeId).HasColumnName("EQSGradeId");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Eqsgrade)
                    .WithMany(p => p.MtEqsgradeLanguage)
                    .HasForeignKey(d => d.EqsgradeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSGradeLanguage_MtEQSGrade");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEqsgradeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSGradeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsownerType>(entity =>
            {
                entity.ToTable("MtEQSOwnerType");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtEqsownerTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EqsownerTypeId, e.LanguageId });

                entity.ToTable("MtEQSOwnerTypeLanguage");

                entity.Property(e => e.EqsownerTypeId).HasColumnName("EQSOwnerTypeId");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.HasOne(d => d.EqsownerType)
                    .WithMany(p => p.MtEqsownerTypeLanguage)
                    .HasForeignKey(d => d.EqsownerTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSOwnerTypeLanguage_MtEQSOwnerType");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEqsownerTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSOwnerTypeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtEqsresponseForm>(entity =>
            {
                entity.ToTable("MtEQSResponseForm");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtEqsresponseFormLanguage>(entity =>
            {
                entity.HasKey(e => new { e.EqsresponseFormId, e.LanguageId });

                entity.ToTable("MtEQSResponseFormLanguage");

                entity.Property(e => e.EqsresponseFormId).HasColumnName("EQSResponseFormID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.EqsresponseForm)
                    .WithMany(p => p.MtEqsresponseFormLanguage)
                    .HasForeignKey(d => d.EqsresponseFormId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSResponseFormLanguage_MtEQSResponseForm");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtEqsresponseFormLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtEQSResponseFormLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGender>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<MtGenderLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GenderId, e.LanguageId });

                entity.Property(e => e.GenderId).HasColumnName("GenderID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(6);

                entity.HasOne(d => d.Gender)
                    .WithMany(p => p.MtGenderLanguage)
                    .HasForeignKey(d => d.GenderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGenderLanguage_MtGender");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGenderLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGenderLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGeographicalDivision>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtGeographicalDivisionLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GeographicalDivisionId, e.LanguageId });

                entity.Property(e => e.GeographicalDivisionId).HasColumnName("GeographicalDivisionID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.GeographicalDivision)
                    .WithMany(p => p.MtGeographicalDivisionLanguage)
                    .HasForeignKey(d => d.GeographicalDivisionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGeographicalDivisionLanguage_MtGeographicalDivision");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGeographicalDivisionLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGeographicalDivisionLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGroundWaterOperationalStatus>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtGroundWaterOperationalStatusLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GroundWaterOperationalStatusId, e.LanguageId });

                entity.Property(e => e.GroundWaterOperationalStatusId).HasColumnName("GroundWaterOperationalStatusID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.GroundWaterOperationalStatus)
                    .WithMany(p => p.MtGroundWaterOperationalStatusLanguage)
                    .HasForeignKey(d => d.GroundWaterOperationalStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterOperationalStatusLanguage_MtGroundWaterOperationalStatus");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGroundWaterOperationalStatusLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterOperationalStatusLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGroundWaterWellLocation>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtGroundWaterWellLocationLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GroundWaterWellLocationId, e.LanguageId });

                entity.Property(e => e.GroundWaterWellLocationId).HasColumnName("GroundWaterWellLocationID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(15);

                entity.HasOne(d => d.GroundWaterWellLocation)
                    .WithMany(p => p.MtGroundWaterWellLocationLanguage)
                    .HasForeignKey(d => d.GroundWaterWellLocationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellLocationLanguage_MtGroundWaterWellLocation");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGroundWaterWellLocationLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellLocationLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGroundWaterWellProductionStatus>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtGroundWaterWellProductionStatusLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GroundWaterWellProductionStatusId, e.LanguageId });

                entity.Property(e => e.GroundWaterWellProductionStatusId).HasColumnName("GroundWaterWellProductionStatusID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(25);

                entity.HasOne(d => d.GroundWaterWellProductionStatus)
                    .WithMany(p => p.MtGroundWaterWellProductionStatusLanguage)
                    .HasForeignKey(d => d.GroundWaterWellProductionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellProductionStatusLanguage_MtGroundWaterWellProductionStatus");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGroundWaterWellProductionStatusLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellProductionStatusLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtGroundWaterWellPurpose>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtGroundWaterWellPurposeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.GroundWaterWellPurposeId, e.LanguageId });

                entity.Property(e => e.GroundWaterWellPurposeId).HasColumnName("GroundWaterWellPurposeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.GroundWaterWellPurpose)
                    .WithMany(p => p.MtGroundWaterWellPurposeLanguage)
                    .HasForeignKey(d => d.GroundWaterWellPurposeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellPurposeLanguage_MtGroundWaterWellPurpose");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtGroundWaterWellPurposeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtGroundWaterWellPurposeLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtLanguage>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Name).HasMaxLength(15);
            });

            modelBuilder.Entity<MtMeasurementUnit>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.HasOne(d => d.MeasuringUnitCategory)
                    .WithMany(p => p.MtMeasurementUnit)
                    .HasForeignKey(d => d.MeasuringUnitCategoryId)
                    .HasConstraintName("FK_MtMeasurementUnit_MtMeasurementUnitCategory");
            });

            modelBuilder.Entity<MtMeasurementUnitCategory>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<MtMeasurementUnitCategoryLanguage>(entity =>
            {
                entity.HasKey(e => new { e.MeasurementUnitCategoryId, e.LanguageId });

                entity.Property(e => e.MeasurementUnitCategoryId).HasColumnName("MeasurementUnitCategoryID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtMeasurementUnitCategoryLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtMeasurementUnitCategoryLanguage_MtLanguage");

                entity.HasOne(d => d.MeasurementUnitCategory)
                    .WithMany(p => p.MtMeasurementUnitCategoryLanguage)
                    .HasForeignKey(d => d.MeasurementUnitCategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtMeasurementUnitCategoryLanguage_MtMeasurementUnitCategory");
            });

            modelBuilder.Entity<MtMeasurementUnitLanguage>(entity =>
            {
                entity.HasKey(e => new { e.MeasurementUnitId, e.LanguageId })
                    .HasName("PK_MtUnitLanguage");

                entity.Property(e => e.MeasurementUnitId).HasColumnName("MeasurementUnitID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtMeasurementUnitLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtMeasurementUnitLanguage_MtLanguage");

                entity.HasOne(d => d.MeasurementUnit)
                    .WithMany(p => p.MtMeasurementUnitLanguage)
                    .HasForeignKey(d => d.MeasurementUnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtMeasurementUnitLanguage_MtMeasurementUnit");
            });

            modelBuilder.Entity<MtMenu>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ParentId).HasColumnName("ParentID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.Url)
                    .HasColumnName("URL")
                    .HasMaxLength(500);

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.InverseParent)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK_MtMenu_MtMenu");
            });

            modelBuilder.Entity<MtMenuLanguage>(entity =>
            {
                entity.HasKey(e => new { e.MenuId, e.LanguageId });

                entity.Property(e => e.MenuId).HasColumnName("MenuID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(1000);

                entity.Property(e => e.Name).HasMaxLength(500);
            });

            modelBuilder.Entity<MtModeOfPayment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtModeOfPaymentLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ModeOfPaymentId, e.LanguageId });

                entity.Property(e => e.ModeOfPaymentId).HasColumnName("ModeOfPaymentID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtModeOfPaymentLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtModeOfPaymentLanguage_MtLanguage");

                entity.HasOne(d => d.ModeOfPayment)
                    .WithMany(p => p.MtModeOfPaymentLanguage)
                    .HasForeignKey(d => d.ModeOfPaymentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtModeOfPaymentLanguage_MtModeOfPayment");
            });

            modelBuilder.Entity<MtNatureOfBusiness>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtNatureOfBusinessLanguage>(entity =>
            {
                entity.HasKey(e => new { e.NatureOfBusinessId, e.LanguageId });

                entity.Property(e => e.NatureOfBusinessId).HasColumnName("NatureOfBusinessID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(200);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtNatureOfBusinessLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtNatureOfBusinessLanguage_MtLanguage");

                entity.HasOne(d => d.NatureOfBusiness)
                    .WithMany(p => p.MtNatureOfBusinessLanguage)
                    .HasForeignKey(d => d.NatureOfBusinessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtNatureOfBusinessLanguage_MtNatureOfBusiness");
            });

            modelBuilder.Entity<MtOrganizationType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtOrganizationTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.OrganizationTypeId, e.LanguageId });

                entity.Property(e => e.OrganizationTypeId).HasColumnName("OrganizationTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtOrganizationTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtOrganizationTypeLanguage_MtLanguage");

                entity.HasOne(d => d.OrganizationType)
                    .WithMany(p => p.MtOrganizationTypeLanguage)
                    .HasForeignKey(d => d.OrganizationTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtOrganizationTypeLanguage_MtOrganizationType");
            });

            modelBuilder.Entity<MtPage>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Page).HasMaxLength(500);

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.Url)
                    .HasColumnName("URL")
                    .HasMaxLength(3000);
            });

            modelBuilder.Entity<MtPaymentFor>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(250);
            });

            modelBuilder.Entity<MtPaymentStatus>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtPaymentStatusLanguage>(entity =>
            {
                entity.HasKey(e => new { e.PaymentStatusId, e.LanguageId });

                entity.Property(e => e.PaymentStatusId).HasColumnName("PaymentStatusID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtPaymentStatusLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPaymentStatusLanguage_MtLanguage");

                entity.HasOne(d => d.PaymentStatus)
                    .WithMany(p => p.MtPaymentStatusLanguage)
                    .HasForeignKey(d => d.PaymentStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPaymentStatusLanguage_MtPaymentStatus");
            });

            modelBuilder.Entity<MtPermitCondition>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtPermitConditionLanguage>(entity =>
            {
                entity.HasKey(e => new { e.PermitConditionId, e.LanguageId });

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Condition).HasMaxLength(1000);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtPermitConditionLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPermitConditionLanguage_MtLanguage");

                entity.HasOne(d => d.PermitCondition)
                    .WithMany(p => p.MtPermitConditionLanguage)
                    .HasForeignKey(d => d.PermitConditionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPermitConditionLanguage_MtPermitCondition");
            });

            modelBuilder.Entity<MtPort>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtPortLanguage>(entity =>
            {
                entity.HasKey(e => new { e.PortId, e.LanguageId });

                entity.Property(e => e.PortId).HasColumnName("PortID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Port).HasMaxLength(255);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtPortLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPortLanguage_MtLanguage");

                entity.HasOne(d => d.PortNavigation)
                    .WithMany(p => p.MtPortLanguage)
                    .HasForeignKey(d => d.PortId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPortLanguage_MtPort");
            });

            modelBuilder.Entity<MtProcess>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Code).HasMaxLength(10);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.Url)
                    .HasColumnName("URL")
                    .HasMaxLength(500);

                entity.HasOne(d => d.ProcessCategory)
                    .WithMany(p => p.MtProcess)
                    .HasForeignKey(d => d.ProcessCategoryId)
                    .HasConstraintName("FK_MtProcess_MtProcessCategory");
            });

            modelBuilder.Entity<MtProcessCategory>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<MtProcessLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ProcessId, e.LanguageId });

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(1000);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtProcessLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProcessLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtProductionGoesTo>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtProductionGoesToLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ProductionGoesToId, e.LanguageId });

                entity.Property(e => e.ProductionGoesToId).HasColumnName("ProductionGoesToID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtProductionGoesToLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProductionGoesToLanguage_MtLanguage");

                entity.HasOne(d => d.ProductionGoesTo)
                    .WithMany(p => p.MtProductionGoesToLanguage)
                    .HasForeignKey(d => d.ProductionGoesToId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProductionGoesToLanguage_MtProductionGoesTo");
            });

            modelBuilder.Entity<MtProfession>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtProfessionLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ProfessionId, e.LanguageId });

                entity.Property(e => e.ProfessionId).HasColumnName("ProfessionID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(150);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtProfessionLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProfessionLanguage_MtLanguage");

                entity.HasOne(d => d.Profession)
                    .WithMany(p => p.MtProfessionLanguage)
                    .HasForeignKey(d => d.ProfessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProfessionLanguage_MtProfession");
            });

            modelBuilder.Entity<MtProfileType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtProfileTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ProfileTypeId, e.LanguageId });

                entity.Property(e => e.ProfileTypeId).HasColumnName("ProfileTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(20);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtProfileTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProfileTypeLanguage_MtLanguage");

                entity.HasOne(d => d.ProfileType)
                    .WithMany(p => p.MtProfileTypeLanguage)
                    .HasForeignKey(d => d.ProfileTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProfileTypeLanguage_MtProfileType");
            });

            modelBuilder.Entity<MtProjectClassification>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.ParentProjectClassification)
                    .WithMany(p => p.InverseParentProjectClassification)
                    .HasForeignKey(d => d.ParentProjectClassificationId)
                    .HasConstraintName("FK_MtProjectClassification_MtProjectClassification");
            });

            modelBuilder.Entity<MtProjectClassificationLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ProjectClassificationId, e.LanguageId });

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(500);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtProjectClassificationLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProjectClassificationLanguage_MtLanguage");

                entity.HasOne(d => d.ProjectClassification)
                    .WithMany(p => p.MtProjectClassificationLanguage)
                    .HasForeignKey(d => d.ProjectClassificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtProjectClassificationLanguage_MtProjectClassification");
            });

            modelBuilder.Entity<MtPropertyType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtPropertyTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.PropertyTypeId, e.LanguageId });

                entity.Property(e => e.PropertyTypeId).HasColumnName("PropertyTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtPropertyTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPropertyTypeLanguage_MtLanguage");

                entity.HasOne(d => d.PropertyType)
                    .WithMany(p => p.MtPropertyTypeLanguage)
                    .HasForeignKey(d => d.PropertyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtPropertyTypeLanguage_MtPropertyType");
            });

            modelBuilder.Entity<MtQuestionAnswerInputType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtQuestionAnswerInputTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.QuestionAnswerInputTypeId, e.LanguageId });

                entity.Property(e => e.QuestionAnswerInputType)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtQuestionAnswerInputTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionAnswerInputTypeLanguage_MtLanguage");

                entity.HasOne(d => d.QuestionAnswerInputTypeNavigation)
                    .WithMany(p => p.MtQuestionAnswerInputTypeLanguage)
                    .HasForeignKey(d => d.QuestionAnswerInputTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionAnswerInputTypeLanguage_MtQuestionAnswerInputType");
            });

            modelBuilder.Entity<MtQuestionnaire>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtQuestionnaireAnswerConfiguration>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.HasOne(d => d.MeasuringUnitCategory)
                    .WithMany(p => p.MtQuestionnaireAnswerConfiguration)
                    .HasForeignKey(d => d.MeasuringUnitCategoryId)
                    .HasConstraintName("FK_MtQuestionnaireAnswerConfiguration_MtMeasurementUnitCategory");

                entity.HasOne(d => d.QuestionAnswerInputType)
                    .WithMany(p => p.MtQuestionnaireAnswerConfiguration)
                    .HasForeignKey(d => d.QuestionAnswerInputTypeId)
                    .HasConstraintName("FK_MtQuestionnaireAnswerConfiguration_MtQuestionAnswerInputType");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.MtQuestionnaireAnswerConfiguration)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .HasConstraintName("FK_MtQuestionnaireAnswerConfiguration_MtQuestionnaire");
            });

            modelBuilder.Entity<MtQuestionnaireAnswerConfigurationLanguage>(entity =>
            {
                entity.HasKey(e => new { e.QuestionnaireAnswerConfigurationId, e.LanguageId });

                entity.Property(e => e.QuestionnaireAnswerConfigurationId).HasColumnName("QuestionnaireAnswerConfigurationID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtQuestionnaireAnswerConfigurationLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireAnswerConfigurationLanguage_MtLanguage");

                entity.HasOne(d => d.QuestionnaireAnswerConfiguration)
                    .WithMany(p => p.MtQuestionnaireAnswerConfigurationLanguage)
                    .HasForeignKey(d => d.QuestionnaireAnswerConfigurationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireAnswerConfigurationLanguage_MtQuestionnaireAnswerConfiguration");
            });

            modelBuilder.Entity<MtQuestionnaireCategory>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtQuestionnaireCategoryLanguage>(entity =>
            {
                entity.HasKey(e => new { e.QuestionnaireCategoryId, e.LanguageId });

                entity.Property(e => e.QuestionnaireCategory)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtQuestionnaireCategoryLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireCategoryLanguage_MtLanguage");

                entity.HasOne(d => d.QuestionnaireCategoryNavigation)
                    .WithMany(p => p.MtQuestionnaireCategoryLanguage)
                    .HasForeignKey(d => d.QuestionnaireCategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireCategoryLanguage_MtQuestionnaireCategory");
            });

            modelBuilder.Entity<MtQuestionnaireLanguage>(entity =>
            {
                entity.HasKey(e => new { e.QuestionnaireId, e.LanguageId });

                entity.Property(e => e.Question).HasMaxLength(500);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtQuestionnaireLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireLanguage_MtLanguage");

                entity.HasOne(d => d.Questionnaire)
                    .WithMany(p => p.MtQuestionnaireLanguage)
                    .HasForeignKey(d => d.QuestionnaireId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtQuestionnaireLanguage_MtQuestionnaire");
            });

            modelBuilder.Entity<MtReportType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtReportTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ReportTypeId, e.LanguageId });

                entity.Property(e => e.ReportTypeId).HasColumnName("ReportTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtReportTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtReportTypeLanguage_MtLanguage");

                entity.HasOne(d => d.ReportType)
                    .WithMany(p => p.MtReportTypeLanguage)
                    .HasForeignKey(d => d.ReportTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtReportTypeLanguage_MtReportType");
            });

            modelBuilder.Entity<MtRole>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtRoleLanguage>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.LanguageId })
                    .HasName("PK_RoleLanguage");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtRoleLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtRoleLanguage_MtLanguage");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.MtRoleLanguage)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtRoleLanguage_MtRole");
            });

            modelBuilder.Entity<MtSector>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.SectorCode).HasMaxLength(10);
            });

            modelBuilder.Entity<MtSectorLanguage>(entity =>
            {
                entity.HasKey(e => new { e.SectorId, e.LanguageId });

                entity.Property(e => e.SectorId)
                    .HasColumnName("SectorID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(200);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtSectorLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtSectorLanguage_MtLanguage");

                entity.HasOne(d => d.Sector)
                    .WithMany(p => p.MtSectorLanguage)
                    .HasForeignKey(d => d.SectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtSectorLanguage_MtSector");
            });

            modelBuilder.Entity<MtStakeHolderType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtStakeHolderTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.StakeHolderTypeId, e.LanguageId });

                entity.Property(e => e.StakeHolderTypeId).HasColumnName("StakeHolderTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtStakeHolderTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtStakeHolderTypeLanguage_MtLanguage");

                entity.HasOne(d => d.StakeHolderType)
                    .WithMany(p => p.MtStakeHolderTypeLanguage)
                    .HasForeignKey(d => d.StakeHolderTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtStakeHolderTypeLanguage_MtStakeHolderType");
            });

            modelBuilder.Entity<MtStatus>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtStatusLanguage>(entity =>
            {
                entity.HasKey(e => new { e.StatusId, e.LanguageId });

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtStatusLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtStatusLanguage_MtLanguage");
            });

            modelBuilder.Entity<MtStudyType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtStudyTypeLanguage>(entity =>
            {
                entity.HasKey(e => new { e.StudyTypeId, e.LanguageId });

                entity.Property(e => e.StudyTypeId).HasColumnName("StudyTypeID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtStudyTypeLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtStudyTypeLanguage_MtLanguage");

                entity.HasOne(d => d.StudyType)
                    .WithMany(p => p.MtStudyTypeLanguage)
                    .HasForeignKey(d => d.StudyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtStudyTypeLanguage_MtStudyType");
            });

            modelBuilder.Entity<MtSubProcess>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtSubProcessLanguage>(entity =>
            {
                entity.HasKey(e => new { e.SubProcessId, e.LanguageId });

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtSubProcessLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtSubProcessLanguage_MtLanguage");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.MtSubProcessLanguage)
                    .HasForeignKey(d => d.SubProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtSubProcessLanguage_MtSubProcess");
            });

            modelBuilder.Entity<MtTeam>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<MtTeamLanguage>(entity =>
            {
                entity.HasKey(e => new { e.TeamId, e.LanguageId });

                entity.Property(e => e.TeamId).HasColumnName("TeamID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name)
                    .HasColumnName("NAME")
                    .HasMaxLength(250);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtTeamLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTeamLanguage_MtLanguage");

                entity.HasOne(d => d.Team)
                    .WithMany(p => p.MtTeamLanguage)
                    .HasForeignKey(d => d.TeamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTeamLanguage_MtTeam");
            });

            modelBuilder.Entity<MtTitle>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtTitleLanguage>(entity =>
            {
                entity.HasKey(e => new { e.TitleId, e.LanguageId });

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtTitleLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTitleLanguage_MtLanguage");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.MtTitleLanguage)
                    .HasForeignKey(d => d.TitleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTitleLanguage_MtTitle");
            });

            modelBuilder.Entity<MtTreeSpecies>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<MtTreeSpeciesLanguage>(entity =>
            {
                entity.HasKey(e => new { e.TreeSpeciesId, e.LanguageId });

                entity.Property(e => e.TreeSpeciesId).HasColumnName("TreeSpeciesID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Name).HasMaxLength(100);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtTreeSpeciesLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTreeSpeciesLanguage_MtLanguage");

                entity.HasOne(d => d.TreeSpecies)
                    .WithMany(p => p.MtTreeSpeciesLanguage)
                    .HasForeignKey(d => d.TreeSpeciesId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtTreeSpeciesLanguage_MtTreeSpecies");
            });

            modelBuilder.Entity<MtZone>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<MtZoneLanguage>(entity =>
            {
                entity.HasKey(e => new { e.ZoneId, e.LanguageId });

                entity.Property(e => e.ZoneId).HasColumnName("ZoneID");

                entity.Property(e => e.LanguageId).HasColumnName("LanguageID");

                entity.Property(e => e.Description).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(5);

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.MtZoneLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtZoneLanguage_MtLanguage");

                entity.HasOne(d => d.Zone)
                    .WithMany(p => p.MtZoneLanguage)
                    .HasForeignKey(d => d.ZoneId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MtZoneLanguage_MtZone");
            });

            modelBuilder.Entity<PaymentDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 3)");

                entity.Property(e => e.ModeofPaymentId).HasColumnName("ModeofPaymentID");

                entity.Property(e => e.PaymentDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentStatusId).HasColumnName("PaymentStatusID");

                entity.Property(e => e.TransactionId)
                    .HasColumnName("TransactionID")
                    .HasMaxLength(20);

                entity.HasOne(d => d.ModeofPayment)
                    .WithMany(p => p.PaymentDetail)
                    .HasForeignKey(d => d.ModeofPaymentId)
                    .HasConstraintName("FK_PaymentDetail_MtModeOfPayment");

                entity.HasOne(d => d.PaymentStatus)
                    .WithMany(p => p.PaymentDetail)
                    .HasForeignKey(d => d.PaymentStatusId)
                    .HasConstraintName("FK_PaymentDetail_MtPaymentStatus");
            });

            modelBuilder.Entity<PermitConditionGroupDeleted>(entity =>
            {
                entity.HasKey(e => e.PermitConditionGroup)
                    .HasName("PK_PermitConditionGroups");

                entity.ToTable("PermitConditionGroup_Deleted");

                entity.Property(e => e.PermitConditionAr).HasColumnName("PermitConditionAR");

                entity.Property(e => e.PermitConditionEn).HasColumnName("PermitConditionEN");
            });

            modelBuilder.Entity<Profile>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommunicationTypeId).HasColumnName("CommunicationTypeID");

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.EmiratesId).HasMaxLength(50);

                entity.Property(e => e.FaxPhone).HasMaxLength(50);

                entity.Property(e => e.FullName).HasMaxLength(250);

                entity.Property(e => e.IsActive).HasDefaultValueSql("((0))");

                entity.Property(e => e.MobilePhone).HasMaxLength(50);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.NationalityId).HasColumnName("NationalityID");

                entity.Property(e => e.PreferredLanguageId).HasColumnName("PreferredLanguageID");

                entity.Property(e => e.ProfileTypeId).HasColumnName("ProfileTypeID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.WorkPhone).HasMaxLength(50);

                entity.HasOne(d => d.CommunicationType)
                    .WithMany(p => p.Profile)
                    .HasForeignKey(d => d.CommunicationTypeId);

                entity.HasOne(d => d.Nationality)
                    .WithMany(p => p.Profile)
                    .HasForeignKey(d => d.NationalityId);

                entity.HasOne(d => d.PreferredLanguage)
                    .WithMany(p => p.Profile)
                    .HasForeignKey(d => d.PreferredLanguageId);

                entity.HasOne(d => d.ProfileType)
                    .WithMany(p => p.Profile)
                    .HasForeignKey(d => d.ProfileTypeId)
                    .HasConstraintName("FK_Profile_ProfileType_ProfileTypeID");
            });

            modelBuilder.Entity<ProfileAddress>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.HasOne(d => d.Address)
                    .WithMany(p => p.ProfileAddress)
                    .HasForeignKey(d => d.AddressId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ProfileCompany>(entity =>
            {
                entity.Property(e => e.CompanyNo).HasMaxLength(50);

                entity.Property(e => e.Description).HasMaxLength(1000);

                entity.Property(e => e.LicenseNo).HasMaxLength(50);

                entity.Property(e => e.ManagerName).HasMaxLength(250);

                entity.Property(e => e.Name).HasMaxLength(500);

                entity.Property(e => e.OwnerName).HasMaxLength(250);

                entity.Property(e => e.ValidFrom).HasColumnType("date");

                entity.Property(e => e.ValidTo).HasColumnType("date");
            });

            modelBuilder.Entity<ProfileContractDetail>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.ContactPerson).HasMaxLength(250);

                entity.Property(e => e.EmailAddress).HasMaxLength(250);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LicenseExpiryDate).HasColumnType("date");

                entity.Property(e => e.LicenseNumber).HasMaxLength(25);

                entity.Property(e => e.LicenseUploadDocumentId).HasColumnName("LicenseUploadDocumentID");

                entity.Property(e => e.MobileNumber).HasMaxLength(15);

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.TelephoneNumber).HasMaxLength(15);

                entity.HasOne(d => d.LicenseUploadDocument)
                    .WithMany(p => p.ProfileContractDetail)
                    .HasForeignKey(d => d.LicenseUploadDocumentId)
                    .HasConstraintName("FK_ProfileContractDetail_UploadedDocument");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.ProfileContractDetail)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProfileContractDetail_Profile");
            });

            modelBuilder.Entity<ProfileDocumentDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.UploadedDocumentId).HasColumnName("UploadedDocumentID");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.ProfileDocumentDetail)
                    .HasForeignKey(d => d.ProfileId)
                    .HasConstraintName("FK_ProfileDocumentDetail_Profile");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.ProfileDocumentDetail)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .HasConstraintName("FK_ProfileDocumentDetail_UploadedDocumentID");
            });

            modelBuilder.Entity<ProfileGovernment>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Ceoname)
                    .HasColumnName("CEOName")
                    .HasMaxLength(250);
            });

            modelBuilder.Entity<ProfileIndividual>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.EmergencyContactName).HasMaxLength(250);

                entity.Property(e => e.EmergencyPhoneNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RecreationalFishingApplication>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationWithUserId).HasColumnName("ApplicationWithUserID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ExpiryDate).HasColumnType("datetime");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LicenseNumber).HasMaxLength(25);

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.RecreationalFishingApplication)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RecreationalFishingApplication_Application");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.RecreationalFishingApplication)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RecreationalFishingApplication_User");

                entity.HasOne(d => d.RenewalParentRecreationalFishingApplication)
                    .WithMany(p => p.InverseRenewalParentRecreationalFishingApplication)
                    .HasForeignKey(d => d.RenewalParentRecreationalFishingApplicationId)
                    .HasConstraintName("FK_RecreationalFishingApplication_RecreationalFishingApplication");
            });

            modelBuilder.Entity<RecreationalFishingDeliveryAddress>(entity =>
            {
                entity.HasIndex(e => e.Id)
                    .HasName("_RecreationalFishingDeliveryAddress");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.RecreationalFishingApplicationId).HasColumnName("RecreationalFishingApplicationID");

                entity.HasOne(d => d.Address)
                    .WithMany(p => p.RecreationalFishingDeliveryAddress)
                    .HasForeignKey(d => d.AddressId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RecreationalFishingDeliveryAddress_Address");

                entity.HasOne(d => d.RecreationalFishingApplication)
                    .WithMany(p => p.RecreationalFishingDeliveryAddress)
                    .HasForeignKey(d => d.RecreationalFishingApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RecreationalFishingDeliveryAddress_RecreationalFishingApplication");
            });

            modelBuilder.Entity<RecreationalFishingPaymentDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.RecreationalFishingApplicationId).HasColumnName("RecreationalFishingApplicationID");

                entity.HasOne(d => d.PaymentDetail)
                    .WithMany(p => p.RecreationalFishingPaymentDetail)
                    .HasForeignKey(d => d.PaymentDetailId)
                    .HasConstraintName("FK_RecreationalFishingPaymentDetail_PaymentDetail");

                entity.HasOne(d => d.PaymentFor)
                    .WithMany(p => p.RecreationalFishingPaymentDetail)
                    .HasForeignKey(d => d.PaymentForId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RecreationalFishingPaymentDetail_MtPaymentFor");

                entity.HasOne(d => d.RecreationalFishingApplication)
                    .WithMany(p => p.RecreationalFishingPaymentDetail)
                    .HasForeignKey(d => d.RecreationalFishingApplicationId)
                    .HasConstraintName("FK_RecreationalFishingPaymentDetail_RecreationalFishingApplication");
            });

            modelBuilder.Entity<RecreationalFishingStatusChangeHistory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Comments).HasMaxLength(500);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RecreationalFishingApplicationId).HasColumnName("RecreationalFishingApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.RecreationalFishingApplication)
                    .WithMany(p => p.RecreationalFishingStatusChangeHistory)
                    .HasForeignKey(d => d.RecreationalFishingApplicationId)
                    .HasConstraintName("FK_RecreationalFishingStatusChangeHistory_RecreationalFishingApplication");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RecreationalFishingStatusChangeHistory)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_RecreationalFishingStatusChangeHistory_MtRole");
            });

            modelBuilder.Entity<ResearchApplication>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AssistanceToEntryToProtectedArea).HasMaxLength(250);

                entity.Property(e => e.ByCatch).HasMaxLength(250);

                entity.Property(e => e.CollectionJustification).HasMaxLength(250);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Curation).HasMaxLength(250);

                entity.Property(e => e.ImpactsMitigation).HasMaxLength(250);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.RequiredDataFromEad).HasColumnName("RequiredDataFromEAD");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.RowRevision)
                    .IsRequired()
                    .IsRowVersion();

                entity.Property(e => e.SpecimenWillBeTakenOutofUae).HasColumnName("SpecimenWillBeTakenOutofUAE");

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.Property(e => e.ValidFrom).HasColumnType("date");

                entity.Property(e => e.ValidTo).HasColumnType("date");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.ResearchApplication)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchApplication_Profile");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.ResearchApplication)
                    .HasForeignKey(d => d.SubProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchApplication_MtSubProcess");
            });

            modelBuilder.Entity<ResearchApplicationStatusChangeHistory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ModifiedByRoleId).HasColumnName("ModifiedByRoleID");

                entity.Property(e => e.ModifiedOn).HasColumnType("datetime");

                entity.Property(e => e.NotificationSmsbody)
                    .HasColumnName("NotificationSMSBody")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmsreceipients)
                    .HasColumnName("NotificationSMSReceipients")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmssent)
                    .HasColumnName("NotificationSMSSent")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.StatusIdfrom).HasColumnName("StatusIDFrom");

                entity.Property(e => e.StatusIdto).HasColumnName("StatusIDTo");

                entity.HasOne(d => d.ModifiedByRole)
                    .WithMany(p => p.ResearchApplicationStatusChangeHistory)
                    .HasForeignKey(d => d.ModifiedByRoleId)
                    .HasConstraintName("FK_ResearchApplicationStatusChangeHistory_MtRole");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchApplicationStatusChangeHistory)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchApplicationStatusChangeHistory_ResearchApplication");
            });

            modelBuilder.Entity<ResearchBiologicalSpecimen>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AgeAndSex).HasMaxLength(100);

                entity.Property(e => e.Comments).HasMaxLength(500);

                entity.Property(e => e.CommonName).HasMaxLength(250);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProtectedAreas).HasMaxLength(500);

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.ScientificName).HasMaxLength(250);

                entity.Property(e => e.ThreatStatus).HasMaxLength(250);

                entity.Property(e => e.TypeOfActivity).HasMaxLength(100);

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchBiologicalSpecimen)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchBiologicalSpecimen_ResearchApplication");
            });

            modelBuilder.Entity<ResearchCollaborator>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommunicationAddress).HasMaxLength(1000);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");

                entity.Property(e => e.EmailAddress).HasMaxLength(300);

                entity.Property(e => e.EmiratesIdnumber)
                    .HasColumnName("EmiratesIDNumber")
                    .HasMaxLength(25);

                entity.Property(e => e.Fax).HasMaxLength(15);

                entity.Property(e => e.FullName).HasMaxLength(250);

                entity.Property(e => e.MobileNumber).HasMaxLength(15);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PhysicalAddress).HasMaxLength(1000);

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.WorkPhone).HasMaxLength(15);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.ResearchCollaborator)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchCollaborator_MtDepartment");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchCollaborator)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchCollaborator_ResearchApplication");
            });

            modelBuilder.Entity<ResearchComment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UploadedDocumentId).HasColumnName("UploadedDocumentID");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchComment)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchComment_ResearchApplication");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.ResearchComment)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_ResearchComment_MtRole");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.ResearchComment)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .HasConstraintName("FK_ResearchComment_UploadedDocument");
            });

            modelBuilder.Entity<ResearchCoworkerDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchCoworkerDetail)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .HasConstraintName("FK_ResearchCoworkerDetail_ResearchApplication");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.ResearchCoworkerDetail)
                    .HasForeignKey(d => d.TitleId)
                    .HasConstraintName("FK_ResearchCoworkerDetail_MtTitle");
            });

            modelBuilder.Entity<ResearchDelayDetailsComment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchDelayDetailsComment)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchDelayDetailsComment_ResearchApplication");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.ResearchDelayDetailsComment)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_ResearchDelayDetailsComment_MtRole");
            });

            modelBuilder.Entity<ResearchProjectDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FieldWorkEndDate).HasColumnType("date");

                entity.Property(e => e.FieldWorkStartDate).HasColumnType("date");

                entity.Property(e => e.InstitutionOrCompany).HasMaxLength(50);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProjectEndDate).HasColumnType("date");

                entity.Property(e => e.ProjectLevel).HasMaxLength(50);

                entity.Property(e => e.ProjectStartDate).HasColumnType("date");

                entity.Property(e => e.ProjectTitle).HasMaxLength(250);

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchProjectDetail)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchProjectDetail_ResearchApplication");
            });

            modelBuilder.Entity<ResearchResearcherDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CommunicationAddress).HasMaxLength(500);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");

                entity.Property(e => e.Email).HasMaxLength(250);

                entity.Property(e => e.Fax).HasMaxLength(15);

                entity.Property(e => e.FullName).HasMaxLength(250);

                entity.Property(e => e.Idnumber)
                    .HasColumnName("IDNumber")
                    .HasMaxLength(25);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.MobileNumber).HasMaxLength(15);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PermanentAddress).HasMaxLength(500);

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.WorkPhone).HasMaxLength(15);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.ResearchResearcherDetail)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchResearcherDetail_MtDepartment");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchResearcherDetail)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchResearcherDetail_ResearchApplication");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.ResearchResearcherDetail)
                    .HasForeignKey(d => d.TitleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchResearcherDetail_MtTitle");
            });

            modelBuilder.Entity<ResearchSupervisorDetail>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DepartmentId).HasColumnName("DepartmentID");

                entity.Property(e => e.EmailAddress).HasMaxLength(250);

                entity.Property(e => e.Fax).HasMaxLength(15);

                entity.Property(e => e.FullName).HasMaxLength(500);

                entity.Property(e => e.Idnumber)
                    .HasColumnName("IDNumber")
                    .HasMaxLength(20);

                entity.Property(e => e.Mobile).HasMaxLength(15);

                entity.Property(e => e.PostalAddress).HasMaxLength(500);

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.WorkPhone).HasMaxLength(15);

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.ResearchSupervisorDetail)
                    .HasForeignKey(d => d.DepartmentId)
                    .HasConstraintName("FK_ResearchSupervisorDetail_MtDepartment");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchSupervisorDetail)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchSupervisorDetail_ResearchApplication");

                entity.HasOne(d => d.Title)
                    .WithMany(p => p.ResearchSupervisorDetail)
                    .HasForeignKey(d => d.TitleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchSupervisorDetail_MtTitle");
            });

            modelBuilder.Entity<ResearchSupportingDocument>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ResearchApplicationId).HasColumnName("ResearchApplicationID");

                entity.Property(e => e.UploadedDocumentId).HasColumnName("UploadedDocumentID");

                entity.HasOne(d => d.ResearchApplication)
                    .WithMany(p => p.ResearchSupportingDocument)
                    .HasForeignKey(d => d.ResearchApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchSupportingDocument_ResearchApplication");

                entity.HasOne(d => d.UploadedDocument)
                    .WithMany(p => p.ResearchSupportingDocument)
                    .HasForeignKey(d => d.UploadedDocumentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ResearchSupportingDocument_UploadedDocument");
            });

            modelBuilder.Entity<Review>(entity =>
            {
                entity.Property(e => e.IsActive).HasDefaultValueSql("((0))");

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<Sla>(entity =>
            {
                entity.ToTable("SLA");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.Sladays).HasColumnName("SLADays");

                entity.Property(e => e.SubProcessId).HasColumnName("SubProcessID");

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.Sla)
                    .HasForeignKey(d => d.SubProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SLA_MtSubProcess");
            });

            modelBuilder.Entity<Threshold>(entity =>
            {
                entity.Property(e => e.ThresholdId).HasColumnName("ThresholdID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Criteria).HasMaxLength(200);

                entity.Property(e => e.Decision).HasMaxLength(200);

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.SectorId).HasColumnName("SectorID");

                entity.Property(e => e.Threshold1)
                    .HasColumnName("Threshold")
                    .HasMaxLength(200);

                entity.Property(e => e.ThresholdValue).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.Sector)
                    .WithMany(p => p.Threshold)
                    .HasForeignKey(d => d.SectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Threshold_MtSector");
            });

            modelBuilder.Entity<TreeTranslocationApplication>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationWithUserId).HasColumnName("ApplicationWithUserID");

                entity.Property(e => e.ApprovalFileId).HasColumnName("ApprovalFileID");

                entity.Property(e => e.CityId).HasColumnName("CityID");

                entity.Property(e => e.ContractorId).HasColumnName("ContractorID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ExpiryDate).HasColumnType("date");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.IssueDate).HasColumnType("date");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.OtherTreeSpecies).HasMaxLength(500);

                entity.Property(e => e.PlantAvailableAreaName).HasMaxLength(250);

                entity.Property(e => e.PlantAvailablePlotNumber).HasMaxLength(10);

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.SitePlanFileId).HasColumnName("SitePlanFileID");

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.TobePlantedArea).HasMaxLength(500);

                entity.Property(e => e.TobePlantedPlotAddress).HasMaxLength(500);

                entity.Property(e => e.TreeSpeciesId).HasColumnName("TreeSpeciesID");

                entity.HasOne(d => d.ApprovalFile)
                    .WithMany(p => p.TreeTranslocationApplicationApprovalFile)
                    .HasForeignKey(d => d.ApprovalFileId)
                    .HasConstraintName("FK_TreeTranslocationApplication_UploadedDocument_ApprovalFileId");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.TreeTranslocationApplication)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TreeTranslocationApplication_MtCity");

                entity.HasOne(d => d.Contractor)
                    .WithMany(p => p.TreeTranslocationApplication)
                    .HasForeignKey(d => d.ContractorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TreeTranslocationApplication_ProfileContractDetail");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.TreeTranslocationApplication)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TreeTranslocationApplication_Profile");

                entity.HasOne(d => d.SitePlanFile)
                    .WithMany(p => p.TreeTranslocationApplicationSitePlanFile)
                    .HasForeignKey(d => d.SitePlanFileId)
                    .HasConstraintName("FK_TreeTranslocationApplication_UploadedDocument_SitePlanFileId");

                entity.HasOne(d => d.TreeSpecies)
                    .WithMany(p => p.TreeTranslocationApplication)
                    .HasForeignKey(d => d.TreeSpeciesId)
                    .HasConstraintName("FK_TreeTranslocationApplication_MtTreeSpecies");
            });

            modelBuilder.Entity<TreeTranslocationComment>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DocumentUploadedId).HasColumnName("DocumentUploadedID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.TreeTranslocationApplicationId).HasColumnName("TreeTranslocationApplicationID");

                entity.HasOne(d => d.DocumentUploaded)
                    .WithMany(p => p.TreeTranslocationComment)
                    .HasForeignKey(d => d.DocumentUploadedId)
                    .HasConstraintName("FK_TreeTranslocationComment_UploadedDocument");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.TreeTranslocationComment)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_TreeTranslocationComment_MtRole");

                entity.HasOne(d => d.TreeTranslocationApplication)
                    .WithMany(p => p.TreeTranslocationComment)
                    .HasForeignKey(d => d.TreeTranslocationApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TreeTranslocationComment_TreeTranslocationApplication");
            });

            modelBuilder.Entity<TreeTranslocationStatusChangeHistory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ModifiedByRoleId).HasColumnName("ModifiedByRoleID");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NotificationEmailSent).HasDefaultValueSql("((0))");

                entity.Property(e => e.NotificationSmsbody)
                    .HasColumnName("NotificationSMSBody")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmsreceipients)
                    .HasColumnName("NotificationSMSReceipients")
                    .HasMaxLength(1000);

                entity.Property(e => e.NotificationSmssent)
                    .HasColumnName("NotificationSMSSent")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.StatusIdfrom).HasColumnName("StatusIDFrom");

                entity.Property(e => e.StatusIdto).HasColumnName("StatusIDTo");

                entity.Property(e => e.TreeTranslocationApplicationId).HasColumnName("TreeTranslocationApplicationID");

                entity.HasOne(d => d.ModifiedByRole)
                    .WithMany(p => p.TreeTranslocationStatusChangeHistory)
                    .HasForeignKey(d => d.ModifiedByRoleId)
                    .HasConstraintName("FK_TreeTranslocationStatusChangeHistory_MtRole");

                entity.HasOne(d => d.TreeTranslocationApplication)
                    .WithMany(p => p.TreeTranslocationStatusChangeHistory)
                    .HasForeignKey(d => d.TreeTranslocationApplicationId)
                    .HasConstraintName("FK_TreeTranslocationStatusChangeHistory_TreeTranslocationApplication");
            });

            modelBuilder.Entity<UploadedDocument>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DocumentExpiryDate).HasColumnType("datetime");

                entity.Property(e => e.DocumentNumber).HasMaxLength(50);

                entity.Property(e => e.Filename).HasMaxLength(256);

                entity.Property(e => e.Location).HasMaxLength(256);

                entity.HasOne(d => d.DocumentType)
                    .WithMany(p => p.UploadedDocument)
                    .HasForeignKey(d => d.DocumentTypeId)
                    .HasConstraintName("FK_UploadedDocument_MtDocumentType");

                entity.HasOne(d => d.IssuedCountry)
                    .WithMany(p => p.UploadedDocument)
                    .HasForeignKey(d => d.IssuedCountryId)
                    .HasConstraintName("FK_UploadedDocument_MtCountry");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.DisplayName).HasMaxLength(250);

                entity.Property(e => e.EmailId)
                    .HasColumnName("EmailID")
                    .HasMaxLength(400);

                entity.Property(e => e.FirstName).HasMaxLength(250);

                entity.Property(e => e.FirstNameAr)
                    .HasColumnName("FirstNameAR")
                    .HasMaxLength(250);

                entity.Property(e => e.GenderId).HasColumnName("GenderID");

                entity.Property(e => e.Initial).HasMaxLength(250);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LastName).HasMaxLength(250);

                entity.Property(e => e.LastNameAr)
                    .HasColumnName("LastNameAR")
                    .HasMaxLength(250);

                entity.Property(e => e.MiddleName).HasMaxLength(250);

                entity.Property(e => e.MiddleNameAr)
                    .HasColumnName("MiddleNameAR")
                    .HasMaxLength(250);

                entity.Property(e => e.MobileNumber).HasMaxLength(10);

                entity.Property(e => e.ModifiedBy).HasMaxLength(20);

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TitleId).HasColumnName("TitleID");

                entity.Property(e => e.UserLogonName).HasMaxLength(20);

                entity.Property(e => e.UserTypeId).HasColumnName("UserTypeID");

                entity.Property(e => e.Uuid)
                    .HasColumnName("UUID")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<UserType>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.UserType1)
                    .HasColumnName("UserType")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Workflow>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailNotificationTeamId).HasColumnName("EmailNotificationTeamID");

                entity.Property(e => e.EmailSubject).HasMaxLength(1000);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Smsbody)
                    .HasColumnName("SMSBody")
                    .HasMaxLength(1000);

                entity.Property(e => e.SmsnotificationTeamId).HasColumnName("SMSNotificationTeamID");

                entity.Property(e => e.Smssubject)
                    .HasColumnName("SMSSubject")
                    .HasMaxLength(500);

                entity.HasOne(d => d.Action)
                    .WithMany(p => p.Workflow)
                    .HasForeignKey(d => d.ActionId)
                    .HasConstraintName("FK_Workflow_MtAction");

                entity.HasOne(d => d.EmailNotificationTeam)
                    .WithMany(p => p.WorkflowEmailNotificationTeam)
                    .HasForeignKey(d => d.EmailNotificationTeamId);

                entity.HasOne(d => d.Fee)
                    .WithMany(p => p.Workflow)
                    .HasForeignKey(d => d.FeeId)
                    .HasConstraintName("FK_Workflow_CtFee");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Workflow)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Workflow_MtRole");

                entity.HasOne(d => d.SmsnotificationTeam)
                    .WithMany(p => p.WorkflowSmsnotificationTeam)
                    .HasForeignKey(d => d.SmsnotificationTeamId);

                entity.HasOne(d => d.SubProcess)
                    .WithMany(p => p.Workflow)
                    .HasForeignKey(d => d.SubProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Workflow_MtSubProcess");
            });
        }
    }
}
