using DigitalServices.BusinessLayer;
using DigitalServices.BusinessLayerInterface;
using DigitalServices.DataAccessLayer;
using DigitalServices.DataAccessLayerInterface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalServicesAPI.Common
{
    public class DependencyInjectionConfig
    {
        public static void AddScope(IServiceCollection services)
        {
            services.AddScoped<ICommonBL, CommonBL>();
            services.AddScoped<ICommonDAL, CommonDAL>();


            services.AddScoped<IUserProfileBL, UserProfileBL>();
            services.AddScoped<IUserProfileDAL, UserProfileDAL>();

            services.AddScoped<IRecreationalFishingBL, RecreationalFishingBL>();
            services.AddScoped<IRecreationalFishingDAL, RecreationalFishingDAL>();

            services.AddScoped<IRasidInspectionBL, RasidInspectionBL>();
            services.AddScoped<IRasidInspectionDAL, RasidInspectionDAL>();


            services.AddScoped<ICustomerHappinessBL, CustomerHappinessBL>();
            services.AddScoped<ICustomerHappinessDAL, CustomerHappinessDAL>();

            services.AddScoped<IPaymentGatewayBL, PaymentGatewayBL>();
            services.AddScoped<IPaymentGatewayDAL, PaymentGatewayDAL>();

            services.AddScoped<IRasidDispatcherBL, RasidDispatcherBL>();
            services.AddScoped<IRasidDispatcherDAL, RasidDispatcherDAL>();

            services.AddScoped<IEQSInternalBL, EQSInternalBL>();
            services.AddScoped<IEQSInternalDAL, EQSInternalDAL>();
            services.AddScoped<IEQSCommonBL, EQSCommonBL>();
            services.AddScoped<IEQSCommonDAL, EQSCommonDAL>();


            services.AddScoped<IECOCustomerBL, ECOCustomerBL>();
            services.AddScoped<IECOCustomerDAL, ECOCustomerDAL>();

            services.AddScoped<IECOInternalBL, ECOInternalBL>();
            services.AddScoped<IECOInternalDAL, ECOInternalDAL>();


            services.AddScoped<IEQSCustomerBL, EQSCustomerBL>();
            services.AddScoped<IEQSCustomerDAL, EQSCustomerDAL>();

            services.AddScoped<IDispatcherDashBoardBL, DispatcherDashBoardBL>();
            services.AddScoped<IDispatcherDashBoardDAL, DispatcherDashBoardDAL>();

            services.AddScoped<IDispatcherInvestigationBL, DispatcherInvestigationBL>();
            services.AddScoped<IDispatcherInvestigationDAL, DispatcherInvestigationDAL>();

            services.AddScoped<IDispatcherRolesAndTeamsBL, DispatcherRolesAndTeamsBL>();
            services.AddScoped<IDispatcherRolesAndTeamsDAL, DispatcherRolesAndTeamsDAL>();

            services.AddScoped<IDispatcherYearlyInspectionDAL, DispatcherYearlyInspectionDAL>();
            services.AddScoped<IDispatcherYearlyInspectionBL, DispatcherYearlyInspectionBL>();

            services.AddScoped<ICommercialFishingBL, CommercialFishingBL>();
            services.AddScoped<ICommercialFishingDAL, CommercialFishingDAL>();

            services.AddScoped<IGroundWaterBL, GroundWaterBL>();
            services.AddScoped<IGroundWaterDAL, GroundWaterDAL>();


            services.AddScoped<ICustomerHappinessInvestigationsDAL, CustomerHappinessInvestigationsDAL>();
            services.AddScoped<ICustomerHappinessInvestigationsBL, CustomerHappinessInvestigationsBL>();

            services.AddScoped<IAquacultureDAL, AquacultureDAL>();
            services.AddScoped<IAquacultureBL, AquacultureBL>();

            services.AddScoped<ITreeTranslocationBL, TreeTranslocationBL>();
            services.AddScoped<ITreeTranslocationDAL, TreeTranslocationDAL>();

            services.AddScoped<IDispatcherStudyRequestDAL, DispatcherStudyRequestDAL>();
            services.AddScoped<IDispatcherStudyRequestBL, DispatcherStudyRequestBL>();

            services.AddScoped<ILegalCaseDAL, LegalCaseDAL>();
            services.AddScoped<ILegalCaseBL, LegalCaseBL>();
        }
    }

}
