using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DigitalServices.DTO.Common;
using DigitalServices.Util;
using DigitalServicesAPI.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Logging;
using NLog;
using static DigitalServices.Util.Enums;

namespace DigitalServicesAPI.Controllers
{
    [AllowAnonymous]
    public class ErrorController : BaseController
    {

        private static readonly Logger logger = LogManager.GetCurrentClassLogger();

        [Route("/error")]
        public IActionResult ErrorLocalDevelopment()
        {
            CustomExceptionDTO customExceptionDTO = new CustomExceptionDTO() ;
            var feature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            var exception = feature?.Error;
            HttpStatusCode status = HttpStatusCode.InternalServerError;
            bool exceptionHandled = false;
           
            
            if (exception.GetType() == typeof(SqlException) && ((System.Data.SqlClient.SqlException)exception).Class == Constants.SQLServerRaiseErrorClass)
            {
                status = HttpStatusCode.PreconditionFailed;
                exceptionHandled = true;
            }

            if (exception.GetType() == typeof(DuplicateExistsException))
            {
                status = HttpStatusCode.PreconditionFailed;
                exceptionHandled = true;
            }
            if (exception.GetType() == typeof(RecordModifiedConcurrencyException))
            {
                status = HttpStatusCode.PreconditionFailed;
                exceptionHandled = true;
            }
            if (exception.GetType() == typeof(RecordNotFoundException))
            {
                status = HttpStatusCode.NoContent;
                exceptionHandled = true;
            }
            if (exception.GetType() == typeof(ThiredPartyIntegrationFailedException))
            {
                status = HttpStatusCode.PreconditionFailed;
                exceptionHandled = true;
            }

            if (exception.GetType() == typeof(BusinessValidationException))
            {
                status = HttpStatusCode.PreconditionFailed;
                exceptionHandled = true;
            }
            if (exception.GetType() == typeof(NoDataAvailableException))
            {
                status = HttpStatusCode.NoContent;
                exceptionHandled = true;
            }

            if (exception.GetType() == typeof(UnauthorizedAccessException))
            {
                status = HttpStatusCode.Unauthorized;
                exceptionHandled = true;

            }
            if (exception.GetType() == typeof(NotImplementedException))
            {
                status = HttpStatusCode.NotImplemented;
                exceptionHandled = true;
            }

            if(exceptionHandled)
            {
                string exceptionMessage = string.Empty;
                string exceptionMessageAr = string.Empty;
                var resorceKeys = exception.Message.Split(',');
                customExceptionDTO.ErrorMessages = new List<ErrorMessageDTO>();
                
                for (int i = 0; i < resorceKeys.Length; i++)
                {
                    if (resorceKeys[i].Trim().Length == 0)
                        continue;
                    exceptionMessage = HelperMethods.GetResourceKeyMessage(resorceKeys[i], (int)LanguageCode.English);
                    exceptionMessageAr = HelperMethods.GetResourceKeyMessage(resorceKeys[i], (int)LanguageCode.Arabic);
                    customExceptionDTO.ErrorMessages.Add(new ErrorMessageDTO { Message = exceptionMessage, MessageAr = exceptionMessageAr });
                }
                customExceptionDTO.ResponseCode = (int)EADResponseCodes.BusinessValidationFailed;
                if(status == HttpStatusCode.Unauthorized)
                {
                    customExceptionDTO.ResponseCode = (int)EADResponseCodes.UnAuthorizedAccess;
                }
                if (string.IsNullOrEmpty(exceptionMessage))
                {
                    customExceptionDTO.ErrorMessages.Add(new ErrorMessageDTO { Message = "Technical issues", MessageAr = "Technical Issue" });
                }

                return new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.OK};
            }

            LogException(exception);
            customExceptionDTO.ErrorMessages = new List<ErrorMessageDTO>();
            customExceptionDTO.ResponseCode = (int)EADResponseCodes.UnHandledExceptionOcured;
            customExceptionDTO.ErrorMessages.Add(new ErrorMessageDTO {Message ="Technical issues",MessageAr ="Technical Issue" });
            return new ObjectResult(customExceptionDTO) { StatusCode = (int)HttpStatusCode.OK };
        }
        

        public ActionResult LogError(string exceptionMessage)
        {
            LogException(new Exception(exceptionMessage));
            return Ok("Error Logged");
        }
        private void LogException(Exception ex)
        {
           //string errorMessage = string.Format("{0} ----- {1}", ex.Message, ex.StackTrace);
            //logger.Log(LogLevel.Error, ex);
            logger.Error(ex, ex.StackTrace);
        
        }
    }
}