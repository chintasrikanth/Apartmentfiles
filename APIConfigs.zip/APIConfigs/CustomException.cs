using DigitalServices.DTO.Common;
using DigitalServices.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace DigitalServicesAPI.Filters
{
    public class CustomExceptionFilter : ExceptionFilterAttribute,IExceptionFilter
    {
        public override void OnException(ExceptionContext context)
        {
            //HttpStatusCode status = HttpStatusCode.InternalServerError;
            //bool exceptionHandled = false;
            //var exception = context.Exception;
            //string exceptionMessage = HelperMethods.GetResourceKeyMessage(exception.Message, 1);
            //if(string.IsNullOrEmpty(exceptionMessage))
            //{
            //    exceptionMessage = exception.Message;
            //}
            //if (exception.GetType() == typeof(SqlException) && ((SqlException)exception).Number == Constants.SQLServerRaiseErrorCode)
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}

            //if (exception.GetType() == typeof(DuplicateExistsException))
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}
            //if (exception.GetType() == typeof(RecordModifiedConcurrencyException))
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}
            //if (exception.GetType() == typeof(RecordNotFoundException))
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}

            //if (exception.GetType() == typeof(DataValidationException))
            //{
            //    status = HttpStatusCode.PreconditionFailed;
            //    exceptionHandled = true;
            //}
            //if (exception.GetType() == typeof(NoDataAvailableException))
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}

            //if (exception.GetType() == typeof(UnauthorizedAccessException))
            //{
            //    status = HttpStatusCode.Unauthorized;
            //    exceptionHandled = true;
                
            //}
            //if (exception.GetType() == typeof(NotImplementedException))
            //{
            //    status = HttpStatusCode.Accepted;
            //    exceptionHandled = true;
            //}

            //if (exceptionHandled)
            //{
            //    var errorMessage = string.Format("{0} Message:{1},MessageAr={2} {3}","{", exceptionMessage, exceptionMessage,"}");
            //    //var test = new CustomExceptionDTO { Message = "Failure", MessageAr = "Ara" };
            //    //JavaScriptSerializer js = new JavaScriptSerializer();
            //    //string json = js.Serialize(test);
            //    //var json = new JavaScriptSerializer().Serialize(test);
            //    return new ObjectResult(new CustomExceptionDTO { Message = "Failure",MessageAr="Ara" }) { StatusCode = (int)status };

            //    context.ExceptionHandled = true;
            //    HttpResponse response = context.HttpContext.Response;
            //    response.StatusCode = (int)status;
            //    response.ContentType = "application/json";
            //    response.WriteAsync(errorMessage);
            //    //response.HttpContext(new ObjectResult(new CustomExceptionDTO { Message = "Failure", MessageAr = "Ara" }) { StatusCode = (int)status }); 
            //    //response.Body( return new ObjectResult(new SSOTAMMToken { Message = "Failure" }) { StatusCode = (int)HttpStatusCode.Unauthorized };);
            //    //response.WriteAsync(exceptionMessage);
            //}
            
        }
    }
}
