using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
//using System.Web.Http.Controllers;
using DigitalServices.DTO.Common;
using DigitalServices.Util;
using DigitalServicesAPI.Common;
//using System.Web.Http.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using static DigitalServices.Util.Enums;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DigitalServicesAPI.Filters
{
    public class Authorization : AuthorizeAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {

            var controllerActionRoleMapping = AppDataCache.GetControllerActionRoleMappingCache(CacheKey.ControllerActionRoleMapping);
            var identity = filterContext.HttpContext.User.Identity as ClaimsIdentity;
            IEnumerable<Claim> claim = identity.Claims;
 
            var userRoleClaim = claim
                .Where(x => x.Type == ClaimTypes.Role)
                .FirstOrDefault();
            int? roleId = null;
           
            if (userRoleClaim != null)
            {
                roleId = TypeConverter.ConvertStringToInt(userRoleClaim.Value);
            }

            var controllerDiscriptor = ((ControllerActionDescriptor)filterContext.ActionDescriptor);
            var controllerName = controllerDiscriptor.ControllerName;
            var actionName = controllerDiscriptor.ActionName;
            /* Permission given at Controller and Action level  */
            var authorizeFilter = controllerActionRoleMapping.Where(p => string.Compare(p.ControllerName, controllerName, true) == 0
            && string.Compare(p.ActionName, actionName, true) == 0).ToList();

            /* If Permission is not given at Controller and Action level     */
            if (authorizeFilter.Count == 0)
            {
                /* Permission given at Controller level( Controller Name is mentioned and Action is null */
                authorizeFilter = controllerActionRoleMapping.Where(p => string.Compare(p.ControllerName, controllerName, true) == 0
            && string.IsNullOrWhiteSpace(p.ActionName)).ToList();
            }
            /* Either controller and Action level Permissions not given or  controller and Action level Permissions given to logged in user role  */
            if (authorizeFilter.Count == 0 || authorizeFilter.Any(p=>p.RoleId == roleId))
            {
                return;
            }

            filterContext.Result = new UnauthorizedResult();
            //throw new UnauthorizedAccessException();

        }
    }
}
