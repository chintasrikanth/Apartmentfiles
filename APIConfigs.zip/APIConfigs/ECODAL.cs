using DigitalServices.DataAccessLayerInterface;
using DigitalServices.DTO.Common;
using System.Collections.Generic;
using System.Threading.Tasks;
using DigitalServices.DTO.EQS;
using DigitalServices.DAL;
using StoredProcedureEFCore;
using DigitalServices.DTO.ECO;
using System.Data.SqlClient;
using System;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Data;
using System.Globalization;
using DigitalServices.Util;
using Org.BouncyCastle.Crypto;

namespace DigitalServices.DataAccessLayer
{
    public class ECOCustomerDAL : DALBase, IECOCustomerDAL
    {
        public async Task<List<SubServiceDashboardDTO>> GetECOReadyForNewRegistrationSelect(ECOInputDTO ecoInputDTO)
        {

            List<SubServiceDashboardDTO> ecoreadyfornewregistration = null;

            await DbContext.LoadStoredProc("dbo.ECONewRegistrationselect")
                 .AddParam("RoleId", ecoInputDTO.RoleId)
                 .AddParam("LanguageId", ecoInputDTO.LanguageId)
                 .AddParam("UserId", ecoInputDTO.UserId)
                 .ExecAsync(async c => ecoreadyfornewregistration = await c.ToListAsync<SubServiceDashboardDTO>());

            return ecoreadyfornewregistration;
        }
        public async Task<List<SubServiceDashboardDTO>> GetECOReadyForRenwalRegistrationSelect(ECOInputDTO ecoInputDTO)
        {

            List<SubServiceDashboardDTO> ecoreadyforrenewalregistration = null;

            await DbContext.LoadStoredProc("dbo.ECOReadyForRenewRegistrationselect")
                 .AddParam("RoleId", ecoInputDTO.RoleId)
                 .AddParam("LanguageId", ecoInputDTO.LanguageId)
                 .AddParam("UserId", ecoInputDTO.UserId)
                 .ExecAsync(async c => ecoreadyforrenewalregistration = await c.ToListAsync<SubServiceDashboardDTO>());

            return ecoreadyforrenewalregistration;
        }
        public async Task<List<SubServiceDashboardDTO>> GetECOReadyForModificationRegistrationSelect(ECOInputDTO ecoInputDTO)
        {

            List<SubServiceDashboardDTO> ecoReadyformodificationRegistration = null;

            await DbContext.LoadStoredProc("dbo.ECOModificationRegistrationselect")
                 .AddParam("RoleId", ecoInputDTO.RoleId)
                 .AddParam("LanguageId", ecoInputDTO.LanguageId)
                 .AddParam("UserId", ecoInputDTO.UserId)
                 .ExecAsync(async c => ecoReadyformodificationRegistration = await c.ToListAsync<SubServiceDashboardDTO>());

            return ecoReadyformodificationRegistration;
        }

        public async Task<ECOProjectDetailsDTO> GetProjectDetails(IdDTO idDTO)
        {

            ECOProjectDetailsDTO ecoprojectdetails = null;

            await DbContext.LoadStoredProc("dbo.ECOProjectDetailsGet")
                 .AddParam("ECOProjectDetailsId", idDTO.Id)
                 .AddParam("RoleId", idDTO.RoleId)
                 .AddParam("LanguageId", idDTO.LanguageId)
                 .AddParam("UserId", idDTO.UserId)
                 .ExecAsync(async c => ecoprojectdetails = await c.FirstOrDefaultAsync<ECOProjectDetailsDTO>());

            return ecoprojectdetails;
        }

        public async Task<ECOFileNamesDTO> GetOtherProjectsExistDocumentId(IdDTO idDTO)
        {

            ECOFileNamesDTO eCOFileNamesDTO = null;

            await DbContext.LoadStoredProc("dbo.ECODocumentDetailsByProjectDetailsIdGet")
                 .AddParam("ECOProjectDetailsId", idDTO.Id)                
                 .ExecAsync(async c => eCOFileNamesDTO = await c.FirstOrDefaultAsync<ECOFileNamesDTO>());

            return eCOFileNamesDTO;
        }
        public async Task<List<ECOProjectDetailsDTO>> GetProjectDetailsList(ECOInputDTO ecoInputDTO)
        {

            List<ECOProjectDetailsDTO> ecoprojectdetails = null;

            await DbContext.LoadStoredProc("dbo.ECOProjectDetailsSelect")
                 .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                 .AddParam("RoleId", ecoInputDTO.RoleId)
                 .AddParam("LanguageId", ecoInputDTO.LanguageId)
                 .AddParam("UserId", ecoInputDTO.UserId)
                 .ExecAsync(async c => ecoprojectdetails = await c.ToListAsync<ECOProjectDetailsDTO>());

            return ecoprojectdetails;
        }

        public async Task<ECOTechnicalTeamDetailsDTO> GetTechnicalTeamsDetails(IdDTO idDTO)
        {

            ECOTechnicalTeamDetailsDTO ecotechnicalteamsdetails = null;

            try
            {
                await DbContext.LoadStoredProc("dbo.ECOTechnicalTeamsDetailsGet")
                     .AddParam("ECOTechnicalTeamDetailsId", idDTO.Id)
                     .AddParam("RoleId", idDTO.RoleId)
                     .AddParam("LanguageId", idDTO.LanguageId)
                     .AddParam("UserId", idDTO.UserId)
                    .ExecAsync(async c => ecotechnicalteamsdetails = await c.FirstOrDefaultAsync<ECOTechnicalTeamDetailsDTO>());

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return ecotechnicalteamsdetails;
        }

        public async Task<List<ECOTechnicalTeamDetailsDTO>> GetTechnicalTeamsDetailsList(ECOInputDTO ecoInputDTO)
        {
            List<ECOTechnicalTeamDetailsDTO> ecotechnicalteamsdetails = null;
            try
            {
                await DbContext.LoadStoredProc("dbo.ECOTechnicalTeamsDetailsSelect")
                     .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                     .AddParam("GetLastApprovedTeamDetails", ecoInputDTO.GetLastApprovedTeamDetails)
                     .AddParam("LanguageId", ecoInputDTO.LanguageId)
                     .AddParam("RoleId", ecoInputDTO.RoleId)
                    .ExecAsync(async c => ecotechnicalteamsdetails = await c.ToListAsync<ECOTechnicalTeamDetailsDTO>());

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ecotechnicalteamsdetails;
        }

        public async Task<ECOTechnicalTeamDetailsDTO> GetECOUploadedDocumentDetailsByTechnicalTeamDetailsId(IdDTO idDTO)
        {
            ECOTechnicalTeamDetailsDTO ecotechnicalteamsdetails = null;
            try
            {
                await DbContext.LoadStoredProc("dbo.ECOUploadedDocumentDetailsByTechnicalTeamDetailsIdGet")
                     .AddParam("ECOTechnicalTeamDetailsId", idDTO.Id)      
                    .ExecAsync(async c => ecotechnicalteamsdetails = await c.FirstOrDefaultAsync<ECOTechnicalTeamDetailsDTO>());

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ecotechnicalteamsdetails;
        }
        public async Task<ECOFieldsOfWorksDTO> GetECOFieldsOfWorks(ECOInputDTO ecoInputDTO)
        {
            ECOFieldsOfWorksDTO ecoFieldsOfWorksDTO = null;

            try
            {
                await DbContext.LoadStoredProc("dbo.ECOFieldsOfWorksSelect")
                     .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                    .ExecAsync(async c => ecoFieldsOfWorksDTO = await c.FirstOrDefaultAsync<ECOFieldsOfWorksDTO>());
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return ecoFieldsOfWorksDTO;
        }
        public async Task<EQSOperationStatusDTO> ECOProjectDetailsSave(ECOProjectDetailsInputDTO ecoprojectdetailsDTO)
        {
            try
            {
                DataTable fieldWorkDTO = ecoprojectdetailsDTO.fieldWorksDTOs.ConvertToDataTable<FieldWorksDTO>();
                var fieldWorkList = new SqlParameter()
                {
                    ParameterName = "ECOFieldWorks",
                    SqlDbType = SqlDbType.Structured,
                    Value = fieldWorkDTO,
                    TypeName = "FieldOfWorks",
                    Direction = ParameterDirection.Input
                };
                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = System.Data.SqlDbType.Timestamp,
                    Direction = System.Data.ParameterDirection.InputOutput,
                    Value = ecoprojectdetailsDTO.RowVersion
                };
                var operationStatusDTO = new EQSOperationStatusDTO();
                await DbContext.LoadStoredProc("dbo.ECOProjectDetailsInsert")
                            .AddParam("EQSApplicationId", ecoprojectdetailsDTO.EQSApplicationId)
                            .AddParam("ProjectName", ecoprojectdetailsDTO.ProjectName)
                            .AddParam("ProjectTypeId", ecoprojectdetailsDTO.ProjectTypeId)
                            .AddParam("OwnerName", ecoprojectdetailsDTO.OwnerName)
                            .AddParam("CountryId", ecoprojectdetailsDTO.CountryId)
                            .AddParam("CityId", ecoprojectdetailsDTO.CityId)
                            .AddParam("RepresentativeName", ecoprojectdetailsDTO.RepresentativeName)
                            .AddParam("DesignationId", ecoprojectdetailsDTO.DesignationId)
                            .AddParam("EmailId", ecoprojectdetailsDTO.EmailId)
                            .AddParam("ContactNumber", ecoprojectdetailsDTO.ContactNumber)
                            .AddParam("DocumentTypeId", ecoprojectdetailsDTO.DocumentTypeId)
                            .AddParam("FileName", ecoprojectdetailsDTO.FileName)
                            .AddParam("CustomerFileName", ecoprojectdetailsDTO.CustomerFileName)
                            .AddParam("FileLocation", ecoprojectdetailsDTO.FileLocation)
                            .AddParam("UserId", ecoprojectdetailsDTO.UserId)
                            .AddParam(fieldWorkList)
                            .AddParam(rowVersionParam)
                            .AddParam("OutParam", out IOutParam<int> outParam)
                            .ExecNonQueryAsync();
                operationStatusDTO.EQSApplicationId = ecoprojectdetailsDTO.EQSApplicationId;
                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
                return operationStatusDTO;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<EQSOperationStatusDTO> ECOProjectDetailsUpdate(ECOProjectDetailsInputDTO ecoprojectdetailsDTO)
        {
            var rowVersionParam = new SqlParameter()
            {
                ParameterName = "@RowVersion",
                SqlDbType = System.Data.SqlDbType.Timestamp,
                Direction = System.Data.ParameterDirection.InputOutput,
                Value = ecoprojectdetailsDTO.RowVersion
            };
            var operationStatusDTO = new EQSOperationStatusDTO();
            await DbContext.LoadStoredProc("dbo.ECOProjectDetailsUpdate")
                        .AddParam("ECOProjectDetailsId", ecoprojectdetailsDTO.Id)
                        .AddParam("ProjectName", ecoprojectdetailsDTO.ProjectName)
                        .AddParam("ProjectScope", ecoprojectdetailsDTO.fieldWorksDTOs[0].ProjectScope)
                        .AddParam("ProjectTypeId", ecoprojectdetailsDTO.ProjectTypeId)
                        .AddParam("OwnerName", ecoprojectdetailsDTO.OwnerName)
                        .AddParam("CountryId", ecoprojectdetailsDTO.CountryId)
                        .AddParam("CityId", ecoprojectdetailsDTO.CityId)
                        .AddParam("RepresentativeName", ecoprojectdetailsDTO.RepresentativeName)
                        .AddParam("DesignationId", ecoprojectdetailsDTO.DesignationId)
                        .AddParam("EmailId", ecoprojectdetailsDTO.EmailId)
                        .AddParam("ContactNumber", ecoprojectdetailsDTO.ContactNumber)
                        .AddParam("EQSApplicationId", ecoprojectdetailsDTO.EQSApplicationId)
                        .AddParam("ECOFieldWorkId", ecoprojectdetailsDTO.fieldWorksDTOs[0].FieldWorkId)
                        .AddParam("ProjectStatusId", ecoprojectdetailsDTO.fieldWorksDTOs[0].ProjectStatusId)
                        .AddParam("StartDate", ecoprojectdetailsDTO.fieldWorksDTOs[0].StartDate)
                        .AddParam("EndDate", ecoprojectdetailsDTO.fieldWorksDTOs[0].EndDate)
                        .AddParam("EvidenceDocumnetId", ecoprojectdetailsDTO.EvidenceDocumnetId)
                        .AddParam("DocumentTypeId", ecoprojectdetailsDTO.DocumentTypeId)
                        .AddParam("FileName", ecoprojectdetailsDTO.FileName)
                        .AddParam("CustomerFileName", ecoprojectdetailsDTO.CustomerFileName)
                        .AddParam("FileLocation", ecoprojectdetailsDTO.FileLocation)
                        .AddParam("UserId", ecoprojectdetailsDTO.UserId)
                        .AddParam(rowVersionParam)
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .ExecNonQueryAsync();
            operationStatusDTO.EQSApplicationId = ecoprojectdetailsDTO.EQSApplicationId;
            operationStatusDTO.TransactionStatus = outParam.Value;
            operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
            return operationStatusDTO;
        }
        public async Task<OperationStatusDTO> ECOProjectDetailsDelete(EQSIdWithRowVersionDTO ecoInputDTO)
        {
            var rowVersionParam = new SqlParameter()
            {
                ParameterName = "@RowVersion",
                SqlDbType = System.Data.SqlDbType.Timestamp,
                Direction = System.Data.ParameterDirection.InputOutput,
                Value = ecoInputDTO.RowVersion
            };
            var operationStatusDTO = new OperationStatusDTO();
            await DbContext.LoadStoredProc("dbo.ECOProjectDetailsDelete")
                        .AddParam("ECOProjectDetailsId", ecoInputDTO.Id)
                        .AddParam(rowVersionParam)
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .ExecNonQueryAsync();
            operationStatusDTO.Id = ecoInputDTO.Id;
            operationStatusDTO.TransactionStatus = outParam.Value;
            operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
            return operationStatusDTO;
        }

        public async Task<OperationStatusDTO> ECOTechnicalTeamsDetailsSave(ECOTechnicalTeamsDetailsInputDTO ecoTechnicalTeamsDetilsInputDTO)
        {
            var operationStatusDTO = new OperationStatusDTO();
            try
            {
                DataTable technicalTeamDetailsLanguageDTO = ecoTechnicalTeamsDetilsInputDTO.TechnicalTeamDetailsLanguageDTO.ConvertToDataTable<ECOTechnicalTeamDetailsLanguageInputDTO>();

                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = System.Data.SqlDbType.Timestamp,
                    Direction = System.Data.ParameterDirection.InputOutput,
                    Value = ecoTechnicalTeamsDetilsInputDTO.RowVersion
                };

                var technicalTeamDetailsLanguageList = new SqlParameter()
                {
                    ParameterName = "IdentityNumberDetails",
                    SqlDbType = SqlDbType.Structured,
                    Value = technicalTeamDetailsLanguageDTO,
                    TypeName = "ECOTechnicalTeamIdentityNumberDetails",
                    Direction = ParameterDirection.Input
                };
                await DbContext.LoadStoredProc("dbo.ECOTechnicalTeamDetailsInsert")
                            .AddParam("EQSApplicationId", ecoTechnicalTeamsDetilsInputDTO.EQSApplicationId)
                            .AddParam("IdTypeId", ecoTechnicalTeamsDetilsInputDTO.IdTypeId)
                            .AddParam("IdentityNumber", ecoTechnicalTeamsDetilsInputDTO.IdentityNumber)
                            .AddParam("DesignationId", ecoTechnicalTeamsDetilsInputDTO.DesignationId)
                            .AddParam("YearsOfExperience", ecoTechnicalTeamsDetilsInputDTO.YearsOfExperience)
                            .AddParam("ECOFieldWorkIds", ecoTechnicalTeamsDetilsInputDTO.FieldWorkIds)
                            .AddParam("DegreeTypeId", ecoTechnicalTeamsDetilsInputDTO.DegreeTypeId)
                            .AddParam("SpecificDegreeType", ecoTechnicalTeamsDetilsInputDTO.SpecificDegreeType)

                            .AddParam("ExpiryDate", ecoTechnicalTeamsDetilsInputDTO.ExpiryDate)
                            .AddParam("ExpiryDateFromIntegration", ecoTechnicalTeamsDetilsInputDTO.ExpiryDateFromIntegration)


                            .AddParam("PassportCopyDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentTypeId)
                            .AddParam("PassportCopyDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentFileName)
                            .AddParam("PassportCopyDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentCustomerFileName)

                            .AddParam("CVDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.CVDocumentTypeId)
                            .AddParam("CVDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.CVDocumentFileName)
                            .AddParam("CVDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.CVDocumentCustomerFileName)

                            .AddParam("DegreeCertificateDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateDocumentTypeId)
                            .AddParam("DegreeCertificateDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateFileName)
                            .AddParam("DegreeCertificateDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateCustomerFileName)

                            .AddParam("FileLocation", ecoTechnicalTeamsDetilsInputDTO.FileLocation)

                            .AddParam(technicalTeamDetailsLanguageList)

                            .AddParam("UserId", ecoTechnicalTeamsDetilsInputDTO.UserId)
                            .AddParam("Id", out IOutParam<int> Id)
                            .AddParam(rowVersionParam)
                            .AddParam("OutParam", out IOutParam<int> outParam)
                            .ExecNonQueryAsync();
                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
                operationStatusDTO.Id = Id.Value;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return operationStatusDTO;
        }

        public async Task<OperationStatusDTO> ECOTechnicalTeamsDetailsUpdate(ECOTechnicalTeamsDetailsInputDTO ecoTechnicalTeamsDetilsInputDTO)
        {
            var operationStatusDTO = new OperationStatusDTO();

            try
            {
                DataTable technicalTeamDetailsLanguageDTO = ecoTechnicalTeamsDetilsInputDTO.TechnicalTeamDetailsLanguageDTO.ConvertToDataTable<ECOTechnicalTeamDetailsLanguageInputDTO>();

                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = System.Data.SqlDbType.Timestamp,
                    Direction = System.Data.ParameterDirection.InputOutput,
                    Value = ecoTechnicalTeamsDetilsInputDTO.RowVersion
                };

                var technicalTeamDetailsLanguageList = new SqlParameter()
                {
                    ParameterName = "IdentityNumberDetails",
                    SqlDbType = SqlDbType.Structured,
                    Value = technicalTeamDetailsLanguageDTO,
                    TypeName = "ECOTechnicalTeamIdentityNumberDetails",
                    Direction = ParameterDirection.Input
                };

                await DbContext.LoadStoredProc("ECOTechnicalTeamDetailsUpdate")
                            .AddParam("ECOTechnicalTeamDetailsId", ecoTechnicalTeamsDetilsInputDTO.Id)
                            .AddParam("IdTypeId", ecoTechnicalTeamsDetilsInputDTO.IdTypeId)
                            .AddParam("IdentityNumber", ecoTechnicalTeamsDetilsInputDTO.IdentityNumber)

                            .AddParam("DesignationId", ecoTechnicalTeamsDetilsInputDTO.DesignationId)
                            .AddParam("YearsOfExperience", ecoTechnicalTeamsDetilsInputDTO.YearsOfExperience)
                            .AddParam("ECOFieldWorkIds", ecoTechnicalTeamsDetilsInputDTO.FieldWorkIds)
                            .AddParam("DegreeTypeId", ecoTechnicalTeamsDetilsInputDTO.DegreeTypeId)
                            .AddParam("SpecificDegreeType", ecoTechnicalTeamsDetilsInputDTO.SpecificDegreeType)

                            .AddParam("ExpiryDate", ecoTechnicalTeamsDetilsInputDTO.ExpiryDate)
                            .AddParam("ExpiryDateFromIntegration", ecoTechnicalTeamsDetilsInputDTO.ExpiryDateFromIntegration)

                            .AddParam("PassportCopyDocumentId", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentId)
                            .AddParam("PassportCopyDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentTypeId)
                            .AddParam("PassportCopyDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentFileName)
                            .AddParam("PassportCopyDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.PassportCopyDocumentCustomerFileName)

                            .AddParam("CVDocumentId", ecoTechnicalTeamsDetilsInputDTO.CVDocumentId)
                            .AddParam("CVDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.CVDocumentTypeId)
                            .AddParam("CVDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.CVDocumentFileName)
                            .AddParam("CVDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.CVDocumentCustomerFileName)

                            .AddParam("DegreeCertificateDocumentId", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateDocumentId)
                            .AddParam("DegreeCertificateDocumentTypeId", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateDocumentTypeId)
                            .AddParam("DegreeCertificateDocumentFileName", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateFileName)
                            .AddParam("DegreeCertificateDocumentCustomerFileName", ecoTechnicalTeamsDetilsInputDTO.DegreeCertificateCustomerFileName)

                            .AddParam("FileLocation", ecoTechnicalTeamsDetilsInputDTO.FileLocation)

                            .AddParam(technicalTeamDetailsLanguageList)

                            .AddParam("UserId", ecoTechnicalTeamsDetilsInputDTO.UserId)
                            .AddParam(rowVersionParam)
                            .AddParam("OutParam", out IOutParam<int> outParam)
                            .ExecNonQueryAsync();
                operationStatusDTO.Id = ecoTechnicalTeamsDetilsInputDTO.Id;
                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);


            }
            catch (Exception ex)
            {

                throw ex;
            }
            return operationStatusDTO;

        }
        public async Task<OperationStatusDTO> ECOTechnicalTeamsDetailsDelete(EQSIdWithRowVersionDTO eqsIdWithRowVersionInputDTO)
        {
            var operationStatusDTO = new OperationStatusDTO();
            try
            {
                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = System.Data.SqlDbType.Timestamp,
                    Direction = System.Data.ParameterDirection.InputOutput,
                    Value = eqsIdWithRowVersionInputDTO.RowVersion
                };

                await DbContext.LoadStoredProc("dbo.ECOTechnicalTeamDetailsDelete")
                            .AddParam("ECOTechnicalTeamDetailsId", eqsIdWithRowVersionInputDTO.Id)
                            .AddParam("UserId", eqsIdWithRowVersionInputDTO.UserId)
                            .AddParam(rowVersionParam)
                            .AddParam("OutParam", out IOutParam<int> outParam)
                            .ExecNonQueryAsync();
                operationStatusDTO.Id = eqsIdWithRowVersionInputDTO.Id;
                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return operationStatusDTO;
        }
        public EQSOperationStatusDTO ECOFieldsOfWorksSave(ECOFieldsOfWorksInputDTO ecoFieldsOfWorksInputDTO,out string savedEcoFieldIds)
        {
            var operationStatusDTO = new EQSOperationStatusDTO();
            try
            {
                var savedEcoFieldWorkIds = new SqlParameter()
                {
                    ParameterName = "@SavedEcoFieldWorkIds",
                    SqlDbType = SqlDbType.NVarChar,
                    Size = -1,
                    Direction = ParameterDirection.Output,
                };

                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = SqlDbType.Timestamp,
                    Direction = ParameterDirection.InputOutput,
                    Value = ecoFieldsOfWorksInputDTO.RowVersion
                };

                DbContext.LoadStoredProc("dbo.ECOFieldsOfWorksSave")
                        .AddParam("EQSApplicationId", ecoFieldsOfWorksInputDTO.EQSApplicationId)
                        .AddParam("ECOFieldWorkIds", ecoFieldsOfWorksInputDTO.FieldWorkIds)
                        .AddParam("UserId", ecoFieldsOfWorksInputDTO.UserId)
                        .AddParam(rowVersionParam)
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .AddParam(savedEcoFieldWorkIds)
              .ExecNonQuery();
                operationStatusDTO.EQSApplicationId = ecoFieldsOfWorksInputDTO.EQSApplicationId;
                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
                savedEcoFieldIds = Convert.ToString(savedEcoFieldWorkIds.Value);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return operationStatusDTO;

        }
        public async Task<EQSOperationStatusDTO> ECODraftRecordDelete(EQSIdWithRowVersionDTO eQSIdWithRowVersionDTO)
        {
            var operationStatusDTO = new EQSOperationStatusDTO();
            var rowVersionParam = new SqlParameter()
            {
                ParameterName = "@RowVersion",
                SqlDbType = SqlDbType.Timestamp,
                Direction = ParameterDirection.InputOutput,
                Value = eQSIdWithRowVersionDTO.RowVersion
            };
            await DbContext.LoadStoredProc("dbo.ECDeleteODraftApplication")
                        .AddParam("EQSApplicationId", eQSIdWithRowVersionDTO.EQSApplicationId)
                        .AddParam("UserId", eQSIdWithRowVersionDTO.UserId)
                        .AddParam("RoleId", eQSIdWithRowVersionDTO.RoleId)
                        .AddParam(rowVersionParam)
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .ExecNonQueryAsync();
            operationStatusDTO.EQSApplicationId = eQSIdWithRowVersionDTO.EQSApplicationId;
            operationStatusDTO.TransactionStatus = outParam.Value;
            return operationStatusDTO;
        }
       
        public string GetExternalEntityLicenseNumber(Int32 EQSApplicationId)
        {
            var ecoPermitDTO = new ECOPermitDTO();
            try
            {
                DbContext.LoadStoredProc("dbo.GetExternalEntityLicenseNumber")
                   .AddParam("EQSApplicationId", EQSApplicationId)
                               .Exec(r => ecoPermitDTO = r.FirstOrDefault<ECOPermitDTO>());

                if (ecoPermitDTO != null)
                    return ecoPermitDTO.ExternalEntityLicenseNumber;

                return null;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        
        public async Task<List<ECOFileNamesDTO>> GetFileNamesToBeDeleted(int EQSApplicationId)
        {
            List<ECOFileNamesDTO> fileNames = null;
            await DbContext.LoadStoredProc("dbo.GetECOFileNamesToBeDeleted")
                .AddParam("EQSApplicationId", EQSApplicationId)
                .ExecAsync(async c => fileNames = await c.ToListAsync<ECOFileNamesDTO>());
            return fileNames;
        }
        public async Task<List<ECOFileNamesDTO>> GetECOALLFileNamesToBeDeleted(ECOInputDTO ecoInputDTO)
        {
            List<ECOFileNamesDTO> fileNames = null;
            await DbContext.LoadStoredProc("dbo.GetECOApplicationFileNamesToBeDeleted")
                .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                .ExecAsync(async c => fileNames = await c.ToListAsync<ECOFileNamesDTO>());
            return fileNames;
        }
        public async Task<List<DropdownItemDTO>> GetConsultantsForStudy(IdDTO idDTO)
        {
            try
            {
                List<DropdownItemDTO> rows = null;
                await DbContext.LoadStoredProc("dbo.GetECOConsultantsForStudyAndReport")
                    .AddParam("EQSFacilityStudyAndReportId", idDTO.Id)
                    .AddParam("LanguageId", idDTO.LanguageId)
                    .ExecAsync(async c => rows = await c.ToListAsync<DropdownItemDTO>());
                return rows;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<List<DropdownItemDTO>> GetDropdownlistOfSavedECOFieldsOfWorks(ECOInputDTO ecoInputDTO)
        {
            List<DropdownItemDTO> dropdownItemsOfecoFieldsofWorks = null;
            try
            {
                await DbContext.LoadStoredProc("dbo.GetDropdownlistOfSavedECOFieldsOfWorks")
                   .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                   .AddParam("LanguageId", ecoInputDTO.LanguageId)
                   .ExecAsync(async c => dropdownItemsOfecoFieldsofWorks = await c.ToListAsync<DropdownItemDTO>());
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dropdownItemsOfecoFieldsofWorks;
        }

        public async Task<List<DropdownItemDTO>> GetDropdownlistOfServiceIdTypes(IdDTO idDTO)
        {
            List<DropdownItemDTO> dropdownItemsOfecoFieldsofWorks = null;
            try
            {
                await DbContext.LoadStoredProc("dbo.GetDropdownlistOfECOServiceIdTypes")
                   .AddParam("ServiceId", idDTO.Id)
                   .ExecAsync(async c => dropdownItemsOfecoFieldsofWorks = await c.ToListAsync<DropdownItemDTO>());
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dropdownItemsOfecoFieldsofWorks;
        }
        public async Task<List<ECOFieldsOfWorkDetailsDTO>> GetECOFieldsOfWorkDetailsList(ECOInputDTO ecoInputDTO)
        {
           List<ECOFieldsOfWorkDetailsDTO> ecoFieldsOfWorkDetailsDTO = null;

                await DbContext.LoadStoredProc("dbo.ECOFieldsOfWorkDetailsSelect")
                    .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                    .AddParam("LanguageId", ecoInputDTO.LanguageId)
                    .ExecAsync(async c => ecoFieldsOfWorkDetailsDTO = await c.ToListAsync<ECOFieldsOfWorkDetailsDTO>());
            return ecoFieldsOfWorkDetailsDTO;
        }
        public async Task<List<ECORemarksDTO>> ECORemarksList(ECOInputDTO idDTO)
        {
            List<ECORemarksDTO> ecoremarksDTO = null;

            await DbContext.LoadStoredProc("dbo.ECORemarksSelect")
               .AddParam("EQSApplicationId", idDTO.EQSApplicationId)
               .AddParam("SearchText", idDTO.SearchText)
               .ExecAsync(async c => ecoremarksDTO = await c.ToListAsync<ECORemarksDTO>());
            return ecoremarksDTO;
        }

        public async Task<EQSSubmitResponseDTO> ECOSubmitApplication(SubmitApplicationInputDTO submitApplicationDTO)
        {

            try
            {

           
            var operationStatusDTO = new EQSSubmitResponseDTO();

            DataTable serviceData = submitApplicationDTO.PaymentDetails.ServiceData.ConvertToDataTable<ServiceData>();

            var serviceDataList = new SqlParameter()
            {
                ParameterName = "PaymentDetailsServiceData",
                SqlDbType = SqlDbType.Structured,
                Value = serviceData,
                TypeName = "PaymentDetailsServiceData",
                Direction = ParameterDirection.Input
            };

            var rowVersionParam = new SqlParameter()
            {
                ParameterName = "@RowVersion",
                SqlDbType = System.Data.SqlDbType.Timestamp,
                Direction = System.Data.ParameterDirection.InputOutput,
                Value = submitApplicationDTO.RowVersion
            };
            await DbContext.LoadStoredProc("dbo.ECOApplicationSubmit")
           .AddParam("EQSApplicationId", submitApplicationDTO.EQSApplicationId)
           .AddParam("ADPayCorrelationId", submitApplicationDTO.PaymentDetails.CorrelationId)
           .AddParam("ADPayApprovalCode", submitApplicationDTO.PaymentDetails.Auth)
           .AddParam("ADPayPaymentDate", TypeConverter.ConvertStringToDate(submitApplicationDTO.PaymentDetails.udf5))
           .AddParam("ADPayTotalAmount", submitApplicationDTO.PaymentDetails.Amt)
           .AddParam("UserId", submitApplicationDTO.UserId)
           .AddParam("RoleId", submitApplicationDTO.RoleId)
           .AddParam(serviceDataList)
           .AddParam(rowVersionParam)
           .AddParam("PaymentDetailsId", out IOutParam<Int64> paymentDetailsId)
           .AddParam("OutParam", out IOutParam<int> outParam)

            .ExecNonQueryAsync();

            operationStatusDTO.PaymentDetailsId = paymentDetailsId.Value;
            operationStatusDTO.EQSApplicationId = submitApplicationDTO.EQSApplicationId;
            operationStatusDTO.TransactionStatus = outParam.Value;
            operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);

            return operationStatusDTO;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public async Task<EQSOperationStatusDTO> ECOApplicationValidate(EQSIdWithRowVersionDTO ecoInputDTO)
        {
            var rowVersionParam = new SqlParameter()
            {
                ParameterName = "@RowVersion",
                SqlDbType = System.Data.SqlDbType.Timestamp,
                Direction = System.Data.ParameterDirection.InputOutput,
                Value = ecoInputDTO.RowVersion
            };
            var operationStatusDTO = new EQSOperationStatusDTO();
            await DbContext.LoadStoredProc("dbo.ECOValidateApplication")
                        .AddParam("EQSApplicationId", ecoInputDTO.EQSApplicationId)
                        .AddParam(rowVersionParam)
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .ExecNonQueryAsync();
            operationStatusDTO.TransactionStatus = outParam.Value;
            operationStatusDTO.EQSApplicationId = ecoInputDTO.EQSApplicationId;
            operationStatusDTO.RowVersion = ecoInputDTO.RowVersion;
            return operationStatusDTO;
        }
        

        public async Task<OperationStatusDTO> ECOApplicationModififcation(EQSIdDTO ecoInputDTO )
        {
            var operationStatusDTO = new OperationStatusDTO();

                var rowVersionParam = new SqlParameter()
                {
                    ParameterName = "@RowVersion",
                    SqlDbType = System.Data.SqlDbType.Timestamp,
                    Direction = System.Data.ParameterDirection.Output,
                    Value = ecoInputDTO.RowVersion
                };

                await DbContext.LoadStoredProc("dbo.ECOApplicationModification")
                        .AddParam("ParentEQSApplicationId", ecoInputDTO.EQSApplicationId)
                        .AddParam("UserId", ecoInputDTO.UserId)                       
                        .AddParam("OutParam", out IOutParam<int> outParam)
                        .AddParam(rowVersionParam)
                        .AddParam("EQSApplicationId", out IOutParam<int> EQSApplicationId)
                        .ExecNonQueryAsync();

                operationStatusDTO.TransactionStatus = outParam.Value;
                operationStatusDTO.RowVersion = TypeConverter.ConvertObjectToRowVersion(rowVersionParam.Value);
                operationStatusDTO.Id = EQSApplicationId.Value;
           
            return operationStatusDTO;
        }

       
    }
}
