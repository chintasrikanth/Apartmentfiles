using DigitalServices.Util;
using DigitalServicesAPI.Common;
using DigitalServicesAPI.Filters;
using DigitalServicesAPI.Scheduler;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System.IO;
using System.Text;
using static DigitalServices.Util.Enums;

namespace DigitalServicesAPI
{

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            
        }

        public IConfiguration Configuration { get; }

        readonly string MyAllowSpecificOrigins = "allowSpecificOrigins";

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            #region "Configuration"

            AppSettingsHelper.config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();

            Constants.DatabaseConnectionString = AppSettingsHelper.DatabaseConnectionString;
            Spire.License.LicenseProvider.SetLicenseKey(AppSettingsHelper.SpireDocLicense);
            #endregion "Configuration"
            services.AddCors(o => o.AddPolicy(MyAllowSpecificOrigins, builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

            services.AddMvc(
           config =>
           {
               config.Filters.Add(typeof(CustomExceptionFilter));
           }
           ).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            DependencyInjectionConfig.AddScope(services);

            // services.AddControllers();
            //Suppress Default ModelState Behaviour
            services.AddControllers()
                    .ConfigureApiBehaviorOptions(
                        options =>
                            {
                                options.SuppressModelStateInvalidFilter = true;
                            });
            #region ScheduledJob
            services.AddSingleton<IHostedService, ScheduleTask>();
            #endregion

            #region "Authentication"

            services.AddMvc(
           config =>
           {
               var policy = new AuthorizationPolicyBuilder()
               .RequireAuthenticatedUser()
               .Build();
               config.Filters.Add(new AuthorizeFilter(policy));
               // config.Filters.Add(new Authorization());
           }
           );
            var JwtSymmetricSecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppSettingsHelper.JwtSecurityKeyValue));
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
           .AddJwtBearer(options =>
           {
               options.SaveToken = true;
               options.RequireHttpsMetadata = false;
               options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
               {
                   ValidateIssuer = true,
                   ValidateAudience = true,
                   ValidAudience = AppSettingsHelper.HomeUrl,
                   ValidIssuer = AppSettingsHelper.HomeUrl,
                   IssuerSigningKey = JwtSymmetricSecurityKey
               };
           });

            #endregion "Authentication"

            #region "Cache Data"

            var cacheOption = new MemoryCacheOptions { };
            AppDataCache.cache = new MemoryCache(cacheOption);
            AppDataCache.Register(CacheKey.ControllerActionRoleMapping, new CacheDataHelper().GetControllerActionRoleMapping);
            AppDataCache.Register(CacheKey.Cities, new CacheDataHelper().GetCitiesForDropdown);
            AppDataCache.Register(CacheKey.Zones, new CacheDataHelper().GetZonesForDropdown);
            AppDataCache.Register(CacheKey.SectorCommunities, new CacheDataHelper().GetSectorCommunitiesForDropdown);
            AppDataCache.Register(CacheKey.ServiceCardList, new CacheDataHelper().GetServiceCardDetails);
            AppDataCache.Register(CacheKey.ProcessByCategory, new CacheDataHelper().GetProcessForDropdown);
            AppDataCache.Register(CacheKey.PaymentRegistration, new CacheDataHelper().GetPaymentRegistrationDetails);
            AppDataCache.Register(CacheKey.IdTypesForECO, new CacheDataHelper().GetIdTypesForDropdownForService);
            AppDataCache.RegisterForDropdown(new CacheDataHelper().GetDataForDropdown);
            AppDataCache.Register(CacheKey.QuestionnaireResponseDropdownValues, new CacheDataHelper().GetQuestionnaireResponseDropdownValues);

            services.AddMemoryCache();

            #endregion "Cache Data"
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}

            if (env.IsDevelopment())
            {
                app.UseExceptionHandler("/error");

            }
            else
            {
                
                app.UseExceptionHandler("/error");
                app.UseHsts();
            }
            #region Authentication
            app.UseAuthentication();

            app.UseAuthorization();
            #endregion Authentication

            app.UseHttpsRedirection();

            app.UseRouting();
            // Enable Cors
            app.UseCors(MyAllowSpecificOrigins);
            app.UseAuthorization();
            //app.UseMvc();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
