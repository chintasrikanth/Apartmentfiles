using AutoMapper;
using DigitalServices.Data.Model;

namespace DigitalServices.DAL
{
    public abstract class DALBase
    {
        private static readonly object padlock = new object();
        private static IMapper iMapper = null;

        private DigitalServicesContext dataContext;


        protected DigitalServicesContext DbContext
        {
            get { return dataContext ?? (dataContext = new DigitalServicesContext()); }
        }


        public IMapper Mapper
        {
            get
            {
                lock (padlock)
                {
                    if (iMapper == null)
                    {
                        iMapper = ObjectMapper.config.CreateMapper();
                    }
                    return iMapper;
                }
            }
        }

    }
}
