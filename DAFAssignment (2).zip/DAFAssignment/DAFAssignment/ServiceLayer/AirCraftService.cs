﻿using DTO;
using RepositoryLayerInterface;
using ServiceLayerInterface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class AirCraftService : IAirCraftService
    {
        private IAirCraftRepository airCraftRepository;

        public AirCraftService(IAirCraftRepository airCraftRepository)
        {
            this.airCraftRepository = airCraftRepository;
        }

        public async Task<OperationStatusDTO> SaveAirCraftsArrivals(AirCraftsDataInputDTO airPlaneArrivalData)
        {
            return await airCraftRepository.SaveAirCraftsArrivals(airPlaneArrivalData);
        }

        public async Task<List<AirCraftDTO>> GetAirCraftDetails(SearchDTO searchData)
        {
            return await airCraftRepository.GetAirCraftDetails(searchData);
        }
    }
}
