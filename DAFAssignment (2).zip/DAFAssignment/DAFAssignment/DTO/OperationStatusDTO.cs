﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class OperationStatusDTO
    {
        public int TransactionStatus { get; set; }
        public string TransactionMessage { get; set; }
    }
}
