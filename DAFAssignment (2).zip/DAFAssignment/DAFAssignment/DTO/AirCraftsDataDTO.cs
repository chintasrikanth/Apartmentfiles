﻿using System;

namespace DTO
{
    public class AirCraftsDataDTO
    {
        public String icao24 { get; set; }
        public long firstSeen { get; set; }
        public String estDepartureAirport { get; set; }
        public long lastSeen { get; set; }
        public String estArrivalAirport { get; set; }
        public string callsign { get; set; }

    }
}
