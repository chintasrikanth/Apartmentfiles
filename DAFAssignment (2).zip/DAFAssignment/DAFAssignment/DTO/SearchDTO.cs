﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class SearchDTO
    {
        public string AirportCode { get; set; }
        public DateTime? SearchDate { get; set; }


    }
}
