﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public  class AirCraftsDataInputDTO
    {
        public List<AirCraftsDataDTO> AirCraftsData { get; set; }
        public string ArrivalOrDeparture { get; set; }
    }
}
