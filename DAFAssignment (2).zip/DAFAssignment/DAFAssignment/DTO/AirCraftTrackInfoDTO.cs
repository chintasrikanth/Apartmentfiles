﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class AirCraftTrackInfoDTO
    {
        public String icao24 { get; set; }
        public int startTime { get; set; }
        public int endTime { get; set; }
        public string callsign { get; set; }
        public List<PathDTO> pathInfo { get; set; }
    }
}
