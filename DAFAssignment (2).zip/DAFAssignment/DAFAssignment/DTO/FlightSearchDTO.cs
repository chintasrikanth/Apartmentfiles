﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DTO
{
    public class FlightSearchDTO
    {
        [Required(ErrorMessage = "FlightNumber is required to search")]
        public string FlightNumber { get; set; }

        [Required(ErrorMessage = "Date is required to search")]
        public DateTime SearchDate { get; set; }

        [Required(ErrorMessage = "EmailId is required")]
        [EmailAddress(ErrorMessage ="EmailId is invalid")]
        public string EmailId { get; set; }
    }
}
