﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class PathDTO
    {
        public int time { get; set; }
        public float? latitude { get; set; }
        public float? longitude { get; set; }
        public float baro_altitude { get; set; }
        public float? true_track { get; set; }
        public bool on_ground { get; set; }
    }
}
