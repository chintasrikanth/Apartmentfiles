﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO
{
    public class AirCraftDTO
    {
        public String icao24 { get; set; }
        public DateTime DepartureDateTime { get; set; }
        public String DepartureAirport { get; set; }
        public DateTime ArrivalDateTime { get; set; }
        public String ArrivalAirport { get; set; }
        public string callsign { get; set; }
        public string ArrivalOrDeparture { get; set; }
    }
}
