﻿using DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayerInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Util;

namespace DAFAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AirCraftController : ControllerBase
    {

        // private variables declaration
        private readonly IAirCraftService airCraftService;


        /// <summary>
        /// contructor - injecting services into the constructor
        /// </summary>
        /// <param name="airCraftService"></param>
        public AirCraftController(IAirCraftService airCraftService)
        {
            this.airCraftService = airCraftService;
        }




        [HttpGet]
        [Route("AirCraftDetailsSave")]
        public async Task<ActionResult> AirCraftDetailsSave()
        {
            AirCraftsDataInputDTO airCraftsData = new AirCraftsDataInputDTO();
            
            string arrivalsDataStatus = "No Data Found",
             DeparturesDataStatus = "No Data Found",
             airportCode = "",
             openSkyApiArrivalsURL = AppSettingsHelpers.ArrivalsUrl,
             openSkyApiDeparturesURL = AppSettingsHelpers.DepartureUrl;



            string[] airportCodes = { "EDDT", "DCA", "AMS", "DEL" };


            DateTime currentDateTime = DateTime.UtcNow;

            long beginTime = HelperMethods.ConvertDateTimeToUnix(currentDateTime);

            long endTime = HelperMethods.ConvertDateTimeToUnix(currentDateTime.AddHours(8));

            foreach (string code in airportCodes)
            {
                airportCode = code;
                // save arrivals data
                openSkyApiArrivalsURL = string.Format(openSkyApiArrivalsURL, airportCode, beginTime, endTime);
                airCraftsData.AirCraftsData = await HelperMethods.GetDataFromRestAPI<List<AirCraftsDataDTO>>(openSkyApiArrivalsURL);
                if (airCraftsData.AirCraftsData != null)
                {
                    airCraftsData.ArrivalOrDeparture = Constants.Arrival;
                    await airCraftService.SaveAirCraftsArrivals(airCraftsData);
                    arrivalsDataStatus = "Data Saved Succesfully";
                }

                // save departures data
                openSkyApiDeparturesURL = string.Format(openSkyApiDeparturesURL, airportCode, beginTime, endTime);
                airCraftsData.AirCraftsData = await HelperMethods.GetDataFromRestAPI<List<AirCraftsDataDTO>>(openSkyApiDeparturesURL);
                if (airCraftsData.AirCraftsData != null)
                {
                    airCraftsData.ArrivalOrDeparture = Constants.Departure;
                    await airCraftService.SaveAirCraftsArrivals(airCraftsData);
                    DeparturesDataStatus = "Data Saved Succesfully";
                }
            }
            return Ok(new
            {
                ArrivalsDataStatus = arrivalsDataStatus,
                DeparturesDataStatus = DeparturesDataStatus,
            });
        }

        [HttpGet]
        [Route("GetAirCraftDetails")]
        public async Task<ActionResult> GetAirCraftDetails([FromBody] SearchDTO searchData)
        {
            var result = await airCraftService.GetAirCraftDetails(searchData);
            return Ok(result);
        }

        [HttpGet]
        [Route("TrackAirCraft")]
        public async Task<ActionResult> TrackAirCraft([FromBody] FlightSearchDTO searchData)
        {
            
            //FlightSearchDTO searchData = new FlightSearchDTO();
            if (!ModelState.IsValid)
            {
                return Ok(ModelState);

            }
            string openSkyTrackURL = AppSettingsHelpers.TrackAirCraftUrl;
            openSkyTrackURL = string.Format(openSkyTrackURL, searchData.FlightNumber, HelperMethods.ConvertDateTimeToUnix(searchData.SearchDate)) ;
            var airCraftTrackInfo = await HelperMethods.GetDataFromRestAPI<AirCraftTrackInfoDTO>(openSkyTrackURL);
            return Ok(airCraftTrackInfo);
        }

    }
}
