﻿using DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RepositoryLayerInterface
{
    public interface IAirCraftRepository
    {
        Task<OperationStatusDTO> SaveAirCraftsArrivals(AirCraftsDataInputDTO airPlaneArrivalData);

        Task<List<AirCraftDTO>> GetAirCraftDetails(SearchDTO searchData);
    }
}
