﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace Util
{
    public static class AppSettingsHelpers
    {
        public static IConfigurationRoot config = null;
        private const string DatabaseConnectionStringKey = "AppSettings:DatabaseConnectionString";

        private const string ArrivalsUrlStringKey = "OpenSkyRestAPIS:Arrival";

        private const string DepartureUrlStringKey = "OpenSkyRestAPIS:Departure";

        private const string TrackUrlStringKey = "OpenSkyRestAPIS:TrackAirCraft";


        public static string DatabaseConnectionString { get { return config[DatabaseConnectionStringKey]; } }

        public static string ArrivalsUrl { get { return config[ArrivalsUrlStringKey]; } }
        public static string DepartureUrl { get { return config[DepartureUrlStringKey]; } }
        public static string TrackAirCraftUrl { get { return config[TrackUrlStringKey]; } }
    }
}
