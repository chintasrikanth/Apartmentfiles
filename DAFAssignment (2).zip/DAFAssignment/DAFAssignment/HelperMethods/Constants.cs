﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Util
{
    public static class Constants
    {
        public static string DatabaseConnectionString = "";

        public const string Arrival = "A";

        public const string Departure = "D";
    }
}
