﻿using Microsoft.Extensions.DependencyInjection;
using RepositoryLayer;
using RepositoryLayerInterface;
using ServiceLayer;
using ServiceLayerInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DAFAssignment.Common
{
    public class DependencyInjectionConfig
    {
        public static void AddScope(IServiceCollection services)
        {
            services.AddScoped<IAirCraftRepository, AirCraftRepository>();
            services.AddScoped<IAirCraftService, AirCraftService>();
        }
    }
}
