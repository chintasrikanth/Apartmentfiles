﻿using DTO;
using Microsoft.Data.SqlClient;
using RepositoryLayerInterface;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Util;

namespace RepositoryLayer
{
    public class AirCraftRepository : RepositoryBase, IAirCraftRepository
    {

        public async Task<List<AirCraftDTO>> GetAirCraftDetails(SearchDTO searchData)
        {
            List<AirCraftDTO> airCraftDetails = null;

            await DbContext.LoadStoredProc("dbo.AirCraftDetailsGet")
                .AddParam("AirportCode", searchData.AirportCode)
                .AddParam("SearchDate", searchData.SearchDate)
                .ExecAsync(async c => airCraftDetails = await c.ToListAsync<AirCraftDTO>());

            return airCraftDetails;
        }


        public async Task<OperationStatusDTO> SaveAirCraftsArrivals(AirCraftsDataInputDTO airCraftsInputData)
        {
            try
            {
                var operationStatus = new OperationStatusDTO();

               DataTable airCrafts = airCraftsInputData.AirCraftsData.ConvertToDataTable<AirCraftsDataDTO>();

                var airCraftsArrivalData = new SqlParameter()
                { 
                    ParameterName = "AirCraftDetails",
                    SqlDbType = SqlDbType.Structured,
                    Value = airCrafts,
                    TypeName = "AirCrafts",
                    Direction = ParameterDirection.Input
                };

                await DbContext.LoadStoredProc("dbo.AirCraftDetailsSave")
                .AddParam(airCraftsArrivalData)
                .AddParam("ArrivalOrDeparture", airCraftsInputData.ArrivalOrDeparture)
                .AddParam("OutParam", out IOutParam<int> outParam)
                .ExecNonQueryAsync();

                operationStatus.TransactionStatus = outParam.Value;

                return operationStatus;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
