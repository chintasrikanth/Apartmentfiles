﻿using Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace RepositoryLayer
{
    public abstract class RepositoryBase
    {
        private ApplicationDbContext dataContext;


        protected ApplicationDbContext DbContext
        {
            get { return dataContext ?? (dataContext = new ApplicationDbContext()); }
        }

    }
}
